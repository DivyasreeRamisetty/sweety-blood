import bcrypt from 'bcryptjs';
import { getDatabase, query } from '../src/backend/db/database.ts';
import { PERMITTED_SLOTS, TimeSlot } from '../src/backend/types.ts';

export async function seedDatabase() {
  console.log('🌱 Starting database seeding for Sweety...');
  await getDatabase(); // Ensure schema is initialized

  // 1. Create or retrieve demo user
  const demoEmail = 'demo@sweety.com';
  const passwordHash = await bcrypt.hash('password123', 10);

  let userResult = await query('SELECT id FROM users WHERE email = $1', [demoEmail]);
  let userId: number;

  if (userResult.rows.length === 0) {
    const insertUser = await query(
      `INSERT INTO users (name, email, password_hash)
       VALUES ($1, $2, $3)
       RETURNING id`,
      ['Sarah Jenkins', demoEmail, passwordHash]
    );
    userId = insertUser.rows[0].id;
    console.log(`Created primary demo user: ${demoEmail} (id: ${userId})`);
  } else {
    userId = userResult.rows[0].id;
    console.log(`Using existing demo user: ${demoEmail} (id: ${userId})`);
  }

  // 2. Create secondary user to demonstrate user isolation
  const secondEmail = 'dr.alex@sweety.com';
  let secondUser = await query('SELECT id FROM users WHERE email = $1', [secondEmail]);
  let secondUserId: number;
  if (secondUser.rows.length === 0) {
    const insertSecond = await query(
      `INSERT INTO users (name, email, password_hash)
       VALUES ($1, $2, $3)
       RETURNING id`,
      ['Dr. Alex Vance', secondEmail, passwordHash]
    );
    secondUserId = insertSecond.rows[0].id;
    console.log(`Created secondary user for isolation testing: ${secondEmail} (id: ${secondUserId})`);
  } else {
    secondUserId = secondUser.rows[0].id;
  }

  // Clear existing readings for clean deterministic seed
  await query('DELETE FROM glucose_readings WHERE user_id = $1', [userId]);
  await query('DELETE FROM glucose_readings WHERE user_id = $1', [secondUserId]);

  // 3. Generate 35 days of readings for demo user (covers entire previous calendar month + month-to-date today)
  const now = new Date();
  const sampleNotes: Record<TimeSlot, string[]> = {
    'Morning (fasting)': [
      'Woke up refreshed. Fasting duration 11h.',
      'Slept 7.5 hours. Baseline test.',
      'Black coffee only prior to test.',
      'Morning hydration 500ml water.',
    ],
    'After breakfast': [
      'Scrambled eggs, sourdough & avocado.',
      'Steel-cut oatmeal with berries & chia seeds.',
      'Greek yogurt with walnuts & honey.',
      'Omelet with spinach, feta & olive oil.',
    ],
    'After lunch': [
      'Quinoa bowl with grilled salmon & broccoli.',
      'Mediterranean salad with chicken breast. 15-min walk.',
      'Lentil soup and mixed greens.',
      'Turkey wrap with hummus and carrots.',
    ],
    'After dinner': [
      'Baked cod, asparagus and roasted sweet potato.',
      'Stir-fried tofu with bell peppers and cauliflower rice.',
      'Grilled chicken salad with balsamic vinaigrette.',
      'Roasted vegetables with brown rice and grilled trout.',
    ],
  };

  const slotBases: Record<TimeSlot, { min: number; max: number }> = {
    'Morning (fasting)': { min: 82, max: 98 },
    'After breakfast': { min: 110, max: 135 },
    'After lunch': { min: 115, max: 142 },
    'After dinner': { min: 120, max: 148 },
  };

  let totalInserted = 0;

  for (let daysAgo = 35; daysAgo >= 0; daysAgo--) {
    const d = new Date(now);
    d.setDate(d.getDate() - daysAgo);
    const dateStr = d.toISOString().split('T')[0];

    // Choose 3 or 4 slots per day
    const slotsToRecord: TimeSlot[] = daysAgo % 3 === 0
      ? [...PERMITTED_SLOTS]
      : ['Morning (fasting)', 'After breakfast', 'After dinner'];

    for (const slot of slotsToRecord) {
      const bounds = slotBases[slot];
      // Generate realistic variance
      const variance = Math.floor(Math.random() * (bounds.max - bounds.min + 1)) + bounds.min;
      const notesList = sampleNotes[slot];
      const note = notesList[Math.floor(Math.random() * notesList.length)];

      await query(
        `INSERT INTO glucose_readings (user_id, reading_date, time_slot, glucose_value, notes)
         VALUES ($1, $2, $3, $4, $5)`,
        [userId, dateStr, slot, variance, note]
      );
      totalInserted++;
    }
  }

  // Insert a couple isolated readings for secondary user
  const todayStr = now.toISOString().split('T')[0];
  await query(
    `INSERT INTO glucose_readings (user_id, reading_date, time_slot, glucose_value, notes)
     VALUES ($1, $2, $3, $4, $5)`,
    [secondUserId, todayStr, 'Morning (fasting)', 94, "Dr. Alex Vance's private morning baseline"]
  );

  console.log(`✅ Seed finished! Inserted ${totalInserted} clinical readings for ${demoEmail}`);
  console.log('----------------------------------------------------');
  console.log('Demo Credentials:');
  console.log(`Email:    ${demoEmail}`);
  console.log(`Password: password123`);
  console.log('----------------------------------------------------');
  
  if (process.argv[1]?.includes('seed')) {
    process.exit(0);
  }
}

// Run directly if called as a script
if (process.argv[1]?.includes('seed')) {
  seedDatabase().catch(err => {
    console.error('Seeding error:', err);
    process.exit(1);
  });
}

