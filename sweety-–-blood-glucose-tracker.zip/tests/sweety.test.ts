import { describe, it, before, after } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import { createApp } from '../server.ts';
import { getDatabase } from '../src/backend/db/database.ts';

let app: any;
let userAToken: string;
let userBToken: string;
let userAId: number;
let userBId: number;
let readingIdUserA: number;

const TEST_DATE_1 = '2026-11-01';
const TEST_DATE_2 = '2026-11-02';

describe('Sweety – Blood Glucose Tracker Backend Test Suite', () => {
  before(async () => {
    process.env.NODE_ENV = 'test';
    app = await createApp();
    await getDatabase();
  });

  // ============================================================================
  // 1. AUTHENTICATION & SECURITY
  // ============================================================================
  describe('1. Authentication & Security', () => {
    it('should register a new user successfully with bcrypt hashed password and return JWT', async () => {
      const res = await request(app)
        .post('/api/auth/register')
        .send({
          name: 'Jane Doe',
          email: 'janedoe@test.com',
          password: 'securePassword123',
        });

      assert.equal(res.status, 201);
      assert.ok(res.body.token);
      assert.equal(res.body.user.email, 'janedoe@test.com');
      assert.equal(res.body.user.name, 'Jane Doe');
      assert.equal(res.body.user.password_hash, undefined, 'Password hash should not be exposed');
      userAToken = res.body.token;
      userAId = res.body.user.id;
    });

    it('should reject registration when email is already registered (409 Conflict)', async () => {
      const res = await request(app)
        .post('/api/auth/register')
        .send({
          name: 'Jane Duplicate',
          email: 'janedoe@test.com',
          password: 'anotherPassword123',
        });

      assert.equal(res.status, 409);
      assert.match(res.body.error, /already exists/i);
    });

    it('should reject registration with short password (< 6 chars)', async () => {
      const res = await request(app)
        .post('/api/auth/register')
        .send({
          name: 'Short Pass',
          email: 'short@test.com',
          password: '123',
        });

      assert.equal(res.status, 400);
      assert.match(res.body.error, /at least 6 characters/i);
    });

    it('should login an existing user with valid credentials', async () => {
      const res = await request(app)
        .post('/api/auth/login')
        .send({
          email: 'janedoe@test.com',
          password: 'securePassword123',
        });

      assert.equal(res.status, 200);
      assert.ok(res.body.token);
      assert.equal(res.body.user.email, 'janedoe@test.com');
    });

    it('should reject login with incorrect password', async () => {
      const res = await request(app)
        .post('/api/auth/login')
        .send({
          email: 'janedoe@test.com',
          password: 'wrongPassword!',
        });

      assert.equal(res.status, 401);
      assert.match(res.body.error, /invalid email or password/i);
    });

    it('should reject unauthenticated requests to protected endpoints', async () => {
      const res = await request(app).get('/api/readings');
      assert.equal(res.status, 401);
      assert.match(res.body.error, /no authorization token/i);
    });

    it('should register a second user for data isolation testing', async () => {
      const res = await request(app)
        .post('/api/auth/register')
        .send({
          name: 'Bob Smith',
          email: 'bob@test.com',
          password: 'password123',
        });

      assert.equal(res.status, 201);
      userBToken = res.body.token;
      userBId = res.body.user.id;
    });
  });

  // ============================================================================
  // 2. GLUCOSE READING VALIDATION
  // ============================================================================
  describe('2. Glucose Reading Validation Rules', () => {
    it('should reject reading without glucose value', async () => {
      const res = await request(app)
        .post('/api/readings')
        .set('Authorization', `Bearer ${userAToken}`)
        .send({
          time_slot: 'Morning (fasting)',
          reading_date: TEST_DATE_1,
        });

      assert.equal(res.status, 400);
      assert.match(res.body.error, /glucose value is required/i);
    });

    it('should reject glucose value below 40 mg/dl', async () => {
      const res = await request(app)
        .post('/api/readings')
        .set('Authorization', `Bearer ${userAToken}`)
        .send({
          glucose_value: 39,
          time_slot: 'Morning (fasting)',
          reading_date: TEST_DATE_1,
        });

      assert.equal(res.status, 400);
      assert.match(res.body.error, /between 40 and 600/i);
    });

    it('should reject glucose value above 600 mg/dl', async () => {
      const res = await request(app)
        .post('/api/readings')
        .set('Authorization', `Bearer ${userAToken}`)
        .send({
          glucose_value: 601,
          time_slot: 'Morning (fasting)',
          reading_date: TEST_DATE_1,
        });

      assert.equal(res.status, 400);
      assert.match(res.body.error, /between 40 and 600/i);
    });

    it('should reject decimal / non-integer glucose value', async () => {
      const res = await request(app)
        .post('/api/readings')
        .set('Authorization', `Bearer ${userAToken}`)
        .send({
          glucose_value: 125.8,
          time_slot: 'Morning (fasting)',
          reading_date: TEST_DATE_1,
        });

      assert.equal(res.status, 400);
      assert.match(res.body.error, /whole number/i);
    });

    it('should reject invalid time slot not in permitted list', async () => {
      const res = await request(app)
        .post('/api/readings')
        .set('Authorization', `Bearer ${userAToken}`)
        .send({
          glucose_value: 110,
          time_slot: 'Midnight Snack', // Invalid
          reading_date: TEST_DATE_1,
        });

      assert.equal(res.status, 400);
      assert.match(res.body.error, /invalid time slot/i);
    });

    it('should reject future reading dates', async () => {
      const futureDate = '2099-12-31';
      const res = await request(app)
        .post('/api/readings')
        .set('Authorization', `Bearer ${userAToken}`)
        .send({
          glucose_value: 115,
          time_slot: 'Morning (fasting)',
          reading_date: futureDate,
        });

      assert.equal(res.status, 400);
      assert.match(res.body.error, /future dates are not allowed/i);
    });

    it('should successfully record a valid reading in permitted slot', async () => {
      const res = await request(app)
        .post('/api/readings')
        .set('Authorization', `Bearer ${userAToken}`)
        .send({
          glucose_value: 95,
          time_slot: 'Morning (fasting)',
          reading_date: TEST_DATE_1,
          notes: 'Fasting 12 hours. Felt energized.',
        });

      assert.equal(res.status, 201);
      assert.equal(res.body.reading.glucose_value, 95);
      assert.equal(res.body.reading.time_slot, 'Morning (fasting)');
      readingIdUserA = res.body.reading.id;
    });
  });

  // ============================================================================
  // 3. DUPLICATE SLOTS & DAILY LIMITS & ISOLATION
  // ============================================================================
  describe('3. Duplicate Slots, Daily Limits & User Isolation', () => {
    it('should reject duplicate reading in the same slot on the same day (409 Conflict)', async () => {
      const res = await request(app)
        .post('/api/readings')
        .set('Authorization', `Bearer ${userAToken}`)
        .send({
          glucose_value: 102,
          time_slot: 'Morning (fasting)', // Already recorded
          reading_date: TEST_DATE_1,
        });

      assert.equal(res.status, 409);
      assert.match(res.body.error, /already exists/i);
    });

    it('should allow adding the remaining 3 permitted slots on the same day', async () => {
      const slots = ['After breakfast', 'After lunch', 'After dinner'];
      const values = [135, 128, 142];

      for (let i = 0; i < slots.length; i++) {
        const res = await request(app)
          .post('/api/readings')
          .set('Authorization', `Bearer ${userAToken}`)
          .send({
            glucose_value: values[i],
            time_slot: slots[i],
            reading_date: TEST_DATE_1,
          });

        assert.equal(res.status, 201);
      }
    });

    it('should enforce user data isolation: User B cannot see User A readings', async () => {
      const res = await request(app)
        .get('/api/readings')
        .set('Authorization', `Bearer ${userBToken}`);

      assert.equal(res.status, 200);
      assert.equal(res.body.readings.length, 0, 'User B should see 0 readings');
    });

    it('should enforce user data isolation: User B cannot edit or delete User A reading', async () => {
      const updateRes = await request(app)
        .put(`/api/readings/${readingIdUserA}`)
        .set('Authorization', `Bearer ${userBToken}`)
        .send({
          glucose_value: 120,
          time_slot: 'Morning (fasting)',
          reading_date: TEST_DATE_1,
        });

      assert.equal(updateRes.status, 404);

      const deleteRes = await request(app)
        .delete(`/api/readings/${readingIdUserA}`)
        .set('Authorization', `Bearer ${userBToken}`);

      assert.equal(deleteRes.status, 404);
    });

    it('should allow User A to edit their reading successfully', async () => {
      const res = await request(app)
        .put(`/api/readings/${readingIdUserA}`)
        .set('Authorization', `Bearer ${userAToken}`)
        .send({
          glucose_value: 98,
          time_slot: 'Morning (fasting)',
          reading_date: TEST_DATE_1,
          notes: 'Updated morning fasting note',
        });

      assert.equal(res.status, 200);
      assert.equal(res.body.reading.glucose_value, 98);
      assert.equal(res.body.reading.notes, 'Updated morning fasting note');
    });
  });

  // ============================================================================
  // 4. REPORTS
  // ============================================================================
  describe('4. Reports: Daily, Month-To-Date & Monthly', () => {
    it('should generate accurate Daily Report for TEST_DATE_1', async () => {
      // Readings on TEST_DATE_1: 98, 135, 128, 142
      // Count: 4, Lowest: 98, Highest: 142, Average: (98+135+128+142)/4 = 503 / 4 = 125.75 -> 125.8
      const res = await request(app)
        .get(`/api/reports/daily?date=${TEST_DATE_1}`)
        .set('Authorization', `Bearer ${userAToken}`);

      assert.equal(res.status, 200);
      assert.equal(res.body.date, TEST_DATE_1);
      assert.equal(res.body.count, 4);
      assert.equal(res.body.lowest, 98);
      assert.equal(res.body.highest, 142);
      assert.equal(res.body.average, 125.8);
      assert.equal(res.body.readings.length, 4);
      // Verify clinical ordering: Morning -> Breakfast -> Lunch -> Dinner
      assert.equal(res.body.readings[0].time_slot, 'Morning (fasting)');
      assert.equal(res.body.readings[3].time_slot, 'After dinner');
    });

    it('should return a friendly empty state for a date with no readings', async () => {
      const res = await request(app)
        .get('/api/reports/daily?date=2026-01-01')
        .set('Authorization', `Bearer ${userAToken}`);

      assert.equal(res.status, 200);
      assert.equal(res.body.count, 0);
      assert.equal(res.body.highest, null);
      assert.equal(res.body.lowest, null);
      assert.equal(res.body.average, null);
      assert.deepEqual(res.body.readings, []);
    });

    it('should generate Month-To-Date Report with accurate stats', async () => {
      const res = await request(app)
        .get(`/api/reports/month-to-date?date=${TEST_DATE_1}`)
        .set('Authorization', `Bearer ${userAToken}`);

      assert.equal(res.status, 200);
      assert.equal(res.body.count, 4);
      assert.equal(res.body.highest, 142);
      assert.equal(res.body.lowest, 98);
      assert.equal(res.body.average, 125.8);
      assert.ok(Array.isArray(res.body.dailyTrends));
      assert.ok(Array.isArray(res.body.slotAverages));
    });

    it('should generate Monthly Report for specified or previous month', async () => {
      const res = await request(app)
        .get('/api/reports/monthly?month=2026-11')
        .set('Authorization', `Bearer ${userAToken}`);

      assert.equal(res.status, 200);
      assert.equal(res.body.count, 4);
      assert.equal(res.body.highest, 142);
      assert.equal(res.body.lowest, 98);
      assert.equal(res.body.average, 125.8);
      assert.ok(res.body.categoryDistribution);
    });
  });
});
