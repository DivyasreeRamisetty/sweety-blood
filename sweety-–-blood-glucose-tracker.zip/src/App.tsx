import React, { useState, useEffect, useCallback } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { Navbar, ActiveTab } from './components/Navbar.tsx';
import { DashboardOverview } from './components/DashboardOverview.tsx';
import { DailyReportView } from './components/DailyReportView.tsx';
import { MonthToDateReportView } from './components/MonthToDateReportView.tsx';
import { MonthlyReportView } from './components/MonthlyReportView.tsx';
import { AiInsightsView } from './components/AiInsightsView.tsx';
import { AddEditReadingModal } from './components/AddEditReadingModal.tsx';
import { DeleteConfirmModal } from './components/DeleteConfirmModal.tsx';
import { AuthScreen } from './components/AuthScreen.tsx';
import { GlucoseReading, TimeSlot, DailyReport } from './types/client.ts';
import { api } from './services/api.ts';
import { CheckCircle2, AlertCircle } from 'lucide-react';

const MainApplication: React.FC = () => {
  const { isAuthenticated, isLoading: isAuthLoading } = useAuth();

  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [dailyReport, setDailyReport] = useState<DailyReport | null>(null);
  const [recentReadings, setRecentReadings] = useState<GlucoseReading[]>([]);
  const [isLoadingData, setIsLoadingData] = useState<boolean>(false);

  // Modal states
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);
  const [modalDefaultSlot, setModalDefaultSlot] = useState<TimeSlot | undefined>();
  const [modalDefaultDate, setModalDefaultDate] = useState<string | undefined>();
  const [readingToEdit, setReadingToEdit] = useState<GlucoseReading | null>(null);

  // Delete modal state
  const [readingToDelete, setReadingToDelete] = useState<GlucoseReading | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  // Toast notification
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 4000);
  };

  const loadDashboardData = useCallback(async () => {
    if (!isAuthenticated) return;
    setIsLoadingData(true);
    try {
      const todayStr = new Date().toISOString().split('T')[0];
      const [dailyRes, readingsRes] = await Promise.all([
        api.getDailyReport(todayStr),
        api.getReadings(),
      ]);
      setDailyReport(dailyRes);
      setRecentReadings(readingsRes.readings);
    } catch (err: any) {
      console.error('Failed to load dashboard data:', err);
    } finally {
      setIsLoadingData(false);
    }
  }, [isAuthenticated]);

  useEffect(() => {
    if (isAuthenticated) {
      loadDashboardData();
    }
  }, [isAuthenticated, loadDashboardData]);

  // Handlers for Add / Edit
  const handleOpenAddModal = (slot?: TimeSlot, date?: string) => {
    setReadingToEdit(null);
    setModalDefaultSlot(slot);
    setModalDefaultDate(date);
    setIsAddModalOpen(true);
  };

  const handleOpenEditModal = (reading: GlucoseReading) => {
    setReadingToEdit(reading);
    setIsAddModalOpen(true);
  };

  const handleReadingSaved = (reading: GlucoseReading) => {
    showToast(
      readingToEdit
        ? `Reading for ${reading.time_slot} updated successfully`
        : `Reading of ${reading.glucose_value} mg/dl recorded for ${reading.time_slot}`
    );
    loadDashboardData();
  };

  // Handlers for Delete
  const handleOpenDeleteModal = (reading: GlucoseReading) => {
    setReadingToDelete(reading);
  };

  const handleConfirmDelete = async () => {
    if (!readingToDelete) return;
    setIsDeleting(true);
    try {
      await api.deleteReading(readingToDelete.id);
      showToast('Reading deleted successfully');
      setReadingToDelete(null);
      loadDashboardData();
    } catch (err: any) {
      showToast(err.message || 'Failed to delete reading', 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  // One-click demo seed handler
  const handleSeedDemo = async () => {
    try {
      await api.seedDemoData();
      showToast('Clinical demo dataset loaded successfully with 35 days of readings!');
      loadDashboardData();
    } catch (err: any) {
      showToast(err.message || 'Failed to seed demo data', 'error');
    }
  };

  if (isAuthLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-3 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
          <p className="text-xs font-semibold text-slate-500">Initializing Sweety...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <AuthScreen />;
  }

  return (
    <div className="min-h-screen bg-slate-50/70 text-slate-800 flex flex-col font-sans">
      {/* Top Bar Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenAddModal={() => handleOpenAddModal()}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {activeTab === 'dashboard' && (
          <DashboardOverview
            dailyReport={dailyReport}
            recentReadings={recentReadings}
            onOpenAddModal={handleOpenAddModal}
            onOpenEditModal={handleOpenEditModal}
            onOpenDeleteModal={handleOpenDeleteModal}
            onNavigateTab={tab => setActiveTab(tab)}
            onSeedDemo={handleSeedDemo}
            isLoading={isLoadingData}
          />
        )}

        {activeTab === 'daily' && (
          <DailyReportView
            onOpenAddModal={handleOpenAddModal}
            onOpenEditModal={handleOpenEditModal}
            onOpenDeleteModal={handleOpenDeleteModal}
          />
        )}

        {activeTab === 'mtd' && (
          <MonthToDateReportView onOpenAddModal={() => handleOpenAddModal()} />
        )}

        {activeTab === 'monthly' && (
          <MonthlyReportView onOpenAddModal={() => handleOpenAddModal()} />
        )}

        {activeTab === 'ai' && <AiInsightsView />}
      </main>

      {/* Modals */}
      <AddEditReadingModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onSuccess={handleReadingSaved}
        readingToEdit={readingToEdit}
        defaultSlot={modalDefaultSlot}
        defaultDate={modalDefaultDate}
      />

      <DeleteConfirmModal
        isOpen={!!readingToDelete}
        onClose={() => setReadingToDelete(null)}
        onConfirm={handleConfirmDelete}
        reading={readingToDelete}
        isDeleting={isDeleting}
      />

      {/* Floating Toast Notification */}
      {toast && (
        <div className="fixed bottom-5 right-5 z-50 animate-fade-in max-w-md">
          <div
            className={`p-3.5 rounded-xl shadow-lg border flex items-center gap-2.5 text-xs font-semibold ${
              toast.type === 'success'
                ? 'bg-slate-900 text-white border-slate-800'
                : 'bg-rose-600 text-white border-rose-700'
            }`}
          >
            {toast.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-teal-400 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-white shrink-0" />
            )}
            <span>{toast.message}</span>
          </div>
        </div>
      )}

      {/* Quiet Professional Footer */}
      <footer className="border-t border-slate-200/80 bg-white py-6 mt-12 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p>
            &copy; {new Date().getFullYear()} Sweety &middot; Blood Glucose Tracker &middot; Kenpath Full Stack Developer Assessment
          </p>
          <div className="flex items-center gap-3 text-[11px] text-slate-400">
            <span>PostgreSQL Database</span>
            <span>&bull;</span>
            <span>bcrypt Hashing</span>
            <span>&bull;</span>
            <span>JWT Auth</span>
            <span>&bull;</span>
            <span>ADA Glycemic Standards</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <MainApplication />
    </AuthProvider>
  );
}
