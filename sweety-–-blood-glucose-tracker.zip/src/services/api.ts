import {
  User,
  GlucoseReading,
  TimeSlot,
  DailyReport,
  MonthToDateReport,
  MonthlyReport,
  AiInsights,
} from '../types/client.ts';

const TOKEN_KEY = 'sweety_auth_token';

export const getStoredToken = (): string | null => {
  return localStorage.getItem(TOKEN_KEY);
};

export const setStoredToken = (token: string | null): void => {
  if (token) {
    localStorage.setItem(TOKEN_KEY, token);
  } else {
    localStorage.removeItem(TOKEN_KEY);
  }
};

async function apiFetch<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers = new Headers(options.headers || {});

  if (!headers.has('Content-Type') && !(options.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }

  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  const response = await fetch(endpoint, {
    ...options,
    headers,
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const errorMsg = data.error || data.message || `Request failed with status ${response.status}`;
    throw new Error(errorMsg);
  }

  return data as T;
}

export const api = {
  // Authentication
  async register(name: string, email: string, password: string) {
    return apiFetch<{ message: string; user: User; token: string }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify({ name, email, password }),
    });
  },

  async login(email: string, password: string) {
    return apiFetch<{ message: string; user: User; token: string }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
  },

  async getMe() {
    return apiFetch<{ user: User }>('/api/auth/me');
  },

  // Glucose Readings
  async getReadings(params?: { date?: string; month?: string; startDate?: string; endDate?: string }) {
    const query = new URLSearchParams();
    if (params?.date) query.set('date', params.date);
    if (params?.month) query.set('month', params.month);
    if (params?.startDate) query.set('startDate', params.startDate);
    if (params?.endDate) query.set('endDate', params.endDate);

    const qs = query.toString();
    return apiFetch<{ readings: GlucoseReading[] }>(`/api/readings${qs ? `?${qs}` : ''}`);
  },

  async createReading(payload: {
    reading_date: string;
    time_slot: TimeSlot;
    glucose_value: number;
    notes?: string;
  }) {
    return apiFetch<{ message: string; reading: GlucoseReading }>('/api/readings', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  async updateReading(
    id: number,
    payload: {
      reading_date: string;
      time_slot: TimeSlot;
      glucose_value: number;
      notes?: string;
    }
  ) {
    return apiFetch<{ message: string; reading: GlucoseReading }>(`/api/readings/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
  },

  async deleteReading(id: number) {
    return apiFetch<{ message: string; id: number }>(`/api/readings/${id}`, {
      method: 'DELETE',
    });
  },

  // Reports
  async getDailyReport(date: string) {
    return apiFetch<DailyReport>(`/api/reports/daily?date=${encodeURIComponent(date)}`);
  },

  async getMonthToDateReport(date: string) {
    return apiFetch<MonthToDateReport>(`/api/reports/month-to-date?date=${encodeURIComponent(date)}`);
  },

  async getMonthlyReport(month?: string) {
    const qs = month ? `?month=${encodeURIComponent(month)}` : '';
    return apiFetch<MonthlyReport>(`/api/reports/monthly${qs}`);
  },

  // AI Clinical Insights
  async getAiInsights() {
    return apiFetch<AiInsights>('/api/ai/insights', {
      method: 'POST',
    });
  },

  // Demo Database Seeder (One-click assessment preview)
  async seedDemoData() {
    return apiFetch<{ message: string; demoCredentials: { email: string; password: string } }>(
      '/api/demo/seed',
      { method: 'POST' }
    );
  },
};
