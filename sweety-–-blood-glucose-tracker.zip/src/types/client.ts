export const PERMITTED_SLOTS = [
  'Morning (fasting)',
  'After breakfast',
  'After lunch',
  'After dinner',
] as const;

export type TimeSlot = typeof PERMITTED_SLOTS[number];

export interface User {
  id: number;
  name: string;
  email: string;
  created_at?: string;
  updated_at?: string;
}

export interface GlucoseReading {
  id: number;
  user_id: number;
  reading_date: string; // YYYY-MM-DD
  time_slot: TimeSlot;
  glucose_value: number; // 40 - 600
  notes?: string | null;
  created_at: string;
  updated_at: string;
}

export interface DailyReport {
  date: string;
  count: number;
  highest: number | null;
  lowest: number | null;
  average: number | null;
  readings: GlucoseReading[];
}

export interface MonthToDateReport {
  startDate: string;
  endDate: string;
  count: number;
  highest: number | null;
  lowest: number | null;
  average: number | null;
  dailyTrends: {
    date: string;
    average: number;
    count: number;
    readings: GlucoseReading[];
  }[];
  slotAverages: {
    slot: TimeSlot;
    average: number | null;
    count: number;
  }[];
}

export interface MonthlyReport {
  month: string;
  monthName: string;
  startDate: string;
  endDate: string;
  count: number;
  highest: number | null;
  lowest: number | null;
  average: number | null;
  categoryDistribution: {
    hypoglycemia: number;
    normal: number;
    elevated: number;
    high: number;
  };
  slotAverages: {
    slot: TimeSlot;
    average: number | null;
    count: number;
  }[];
}

export interface AiInsights {
  summary: string;
  highlights: string[];
  recommendations: string[];
  glycemicStability: string;
}
