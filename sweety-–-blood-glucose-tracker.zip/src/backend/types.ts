/**
 * Types & Schemas for Sweety – Blood Glucose Tracker
 */

export const PERMITTED_SLOTS = [
  'Morning (fasting)',
  'After breakfast',
  'After lunch',
  'After dinner',
] as const;

export type TimeSlot = typeof PERMITTED_SLOTS[number];

export interface User {
  id: number;
  name: string;
  email: string;
  created_at: string;
  updated_at: string;
}

export interface UserWithPassword extends User {
  password_hash: string;
}

export interface GlucoseReading {
  id: number;
  user_id: number;
  reading_date: string; // YYYY-MM-DD
  time_slot: TimeSlot;
  glucose_value: number; // mg/dl (40 - 600)
  notes?: string | null;
  created_at: string;
  updated_at: string;
}

export interface DailyReport {
  date: string;
  count: number;
  highest: number | null;
  lowest: number | null;
  average: number | null;
  readings: GlucoseReading[];
}

export interface MonthToDateReport {
  startDate: string;
  endDate: string;
  count: number;
  highest: number | null;
  lowest: number | null;
  average: number | null;
  dailyTrends: {
    date: string;
    average: number;
    count: number;
    readings: GlucoseReading[];
  }[];
  slotAverages: {
    slot: TimeSlot;
    average: number | null;
    count: number;
  }[];
}

export interface MonthlyReport {
  month: string; // YYYY-MM
  monthName: string; // e.g. "October 2026"
  startDate: string;
  endDate: string;
  count: number;
  highest: number | null;
  lowest: number | null;
  average: number | null;
  categoryDistribution: {
    hypoglycemia: number; // < 70
    normal: number; // 70 - 140
    elevated: number; // 141 - 180
    high: number; // > 180
  };
  slotAverages: {
    slot: TimeSlot;
    average: number | null;
    count: number;
  }[];
}

export interface AuthTokenPayload {
  id: number;
  email: string;
  name: string;
}
