import { Router, Response } from 'express';
import { query } from '../db/database.ts';
import { authenticateJWT, AuthenticatedRequest } from '../middleware/auth.ts';
import {
  PERMITTED_SLOTS,
  TimeSlot,
  GlucoseReading,
  DailyReport,
  MonthToDateReport,
  MonthlyReport,
} from '../types.ts';

export const reportsRouter = Router();

// Protect all reports routes with JWT authentication
reportsRouter.use(authenticateJWT);

const SLOT_ORDER: Record<TimeSlot, number> = {
  'Morning (fasting)': 1,
  'After breakfast': 2,
  'After lunch': 3,
  'After dinner': 4,
};

function normalizeDate(val: any): string {
  if (!val) return '';
  if (typeof val === 'string') return val.split('T')[0];
  if (val instanceof Date) return val.toISOString().split('T')[0];
  return String(val);
}

function calculateSummary(readings: GlucoseReading[]) {
  if (readings.length === 0) {
    return {
      count: 0,
      highest: null,
      lowest: null,
      average: null,
    };
  }

  let highest = readings[0].glucose_value;
  let lowest = readings[0].glucose_value;
  let sum = 0;

  for (const r of readings) {
    if (r.glucose_value > highest) highest = r.glucose_value;
    if (r.glucose_value < lowest) lowest = r.glucose_value;
    sum += r.glucose_value;
  }

  const avg = Math.round((sum / readings.length) * 10) / 10;

  return {
    count: readings.length,
    highest,
    lowest,
    average: avg,
  };
}

/**
 * GET /api/reports/daily
 * Daily report for a selected date.
 * Query params: ?date=YYYY-MM-DD (defaults to today)
 */
reportsRouter.get('/daily', async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.id;
    const requestedDate = (req.query.date as string) || new Date().toISOString().split('T')[0];

    const result = await query<GlucoseReading>(
      `SELECT id, user_id, reading_date, time_slot, glucose_value, notes, created_at, updated_at
       FROM glucose_readings
       WHERE user_id = $1 AND reading_date = $2
       ORDER BY created_at ASC`,
      [userId, requestedDate]
    );

    const formattedReadings = result.rows.map(r => ({
      ...r,
      reading_date: normalizeDate(r.reading_date),
    }));

    // Sort by clinical meal slot order
    formattedReadings.sort((a, b) => {
      const orderA = SLOT_ORDER[a.time_slot] || 99;
      const orderB = SLOT_ORDER[b.time_slot] || 99;
      return orderA - orderB;
    });

    const summary = calculateSummary(formattedReadings);

    const report: DailyReport = {
      date: requestedDate,
      count: summary.count,
      highest: summary.highest,
      lowest: summary.lowest,
      average: summary.average,
      readings: formattedReadings,
    };

    res.json(report);
  } catch (error: any) {
    console.error('Error generating daily report:', error);
    res.status(500).json({ error: 'Failed to generate daily report' });
  }
});

/**
 * GET /api/reports/month-to-date
 * Month-to-date report from first day of month through selected date.
 * Query params: ?date=YYYY-MM-DD (defaults to today)
 */
reportsRouter.get('/month-to-date', async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.id;
    const requestedDate = (req.query.date as string) || new Date().toISOString().split('T')[0];

    // Compute start of the month (e.g., 2026-11-01)
    const [yearStr, monthStr] = requestedDate.split('-');
    const startDate = `${yearStr}-${monthStr}-01`;
    const endDate = requestedDate;

    const result = await query<GlucoseReading>(
      `SELECT id, user_id, reading_date, time_slot, glucose_value, notes, created_at, updated_at
       FROM glucose_readings
       WHERE user_id = $1 AND reading_date >= $2 AND reading_date <= $3
       ORDER BY reading_date ASC, id ASC`,
      [userId, startDate, endDate]
    );

    const formattedReadings = result.rows.map(r => ({
      ...r,
      reading_date: normalizeDate(r.reading_date),
    }));

    const summary = calculateSummary(formattedReadings);

    // Group by date for daily trends
    const dailyMap = new Map<string, GlucoseReading[]>();
    for (const r of formattedReadings) {
      const dateKey = r.reading_date;
      if (!dailyMap.has(dateKey)) dailyMap.set(dateKey, []);
      dailyMap.get(dateKey)!.push(r);
    }

    const dailyTrends = Array.from(dailyMap.entries()).map(([date, items]) => {
      const daySum = items.reduce((acc, curr) => acc + curr.glucose_value, 0);
      return {
        date,
        average: Math.round((daySum / items.length) * 10) / 10,
        count: items.length,
        readings: items,
      };
    });

    // Slot breakdown
    const slotAverages = PERMITTED_SLOTS.map(slot => {
      const slotReadings = formattedReadings.filter(r => r.time_slot === slot);
      if (slotReadings.length === 0) {
        return { slot, average: null, count: 0 };
      }
      const sum = slotReadings.reduce((acc, curr) => acc + curr.glucose_value, 0);
      return {
        slot,
        average: Math.round((sum / slotReadings.length) * 10) / 10,
        count: slotReadings.length,
      };
    });

    const report: MonthToDateReport = {
      startDate,
      endDate,
      count: summary.count,
      highest: summary.highest,
      lowest: summary.lowest,
      average: summary.average,
      dailyTrends,
      slotAverages,
    };

    res.json(report);
  } catch (error: any) {
    console.error('Error generating MTD report:', error);
    res.status(500).json({ error: 'Failed to generate month-to-date report' });
  }
});

/**
 * GET /api/reports/monthly
 * Entire previous calendar month report (or specified ?month=YYYY-MM).
 */
reportsRouter.get('/monthly', async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.id;
    let targetMonth = req.query.month as string;

    if (!targetMonth) {
      // Default to entire PREVIOUS calendar month as explicitly required in requirements!
      const now = new Date();
      let prevYear = now.getFullYear();
      let prevMonthNum = now.getMonth(); // 0-11, so current month index is previous month number (1-12)
      if (prevMonthNum === 0) {
        prevMonthNum = 12;
        prevYear -= 1;
      }
      targetMonth = `${prevYear}-${String(prevMonthNum).padStart(2, '0')}`;
    }

    const [yStr, mStr] = targetMonth.split('-');
    const year = parseInt(yStr, 10);
    const monthIndex = parseInt(mStr, 10); // 1-12
    const startDate = `${targetMonth}-01`;
    const lastDay = new Date(year, monthIndex, 0).getDate();
    const endDate = `${targetMonth}-${String(lastDay).padStart(2, '0')}`;

    // Get friendly name e.g. "October 2026"
    const monthDateObj = new Date(year, monthIndex - 1, 1);
    const monthName = monthDateObj.toLocaleString('en-US', { month: 'long', year: 'numeric' });

    const result = await query<GlucoseReading>(
      `SELECT id, user_id, reading_date, time_slot, glucose_value, notes, created_at, updated_at
       FROM glucose_readings
       WHERE user_id = $1 AND reading_date >= $2 AND reading_date <= $3
       ORDER BY reading_date ASC, id ASC`,
      [userId, startDate, endDate]
    );

    const formattedReadings = result.rows.map(r => ({
      ...r,
      reading_date: normalizeDate(r.reading_date),
    }));

    const summary = calculateSummary(formattedReadings);

    // ADA Glycemic Category Distribution
    const categoryDistribution = {
      hypoglycemia: 0, // < 70
      normal: 0, // 70 - 140
      elevated: 0, // 141 - 180
      high: 0, // > 180
    };

    for (const r of formattedReadings) {
      if (r.glucose_value < 70) categoryDistribution.hypoglycemia++;
      else if (r.glucose_value <= 140) categoryDistribution.normal++;
      else if (r.glucose_value <= 180) categoryDistribution.elevated++;
      else categoryDistribution.high++;
    }

    // Slot breakdown
    const slotAverages = PERMITTED_SLOTS.map(slot => {
      const slotReadings = formattedReadings.filter(r => r.time_slot === slot);
      if (slotReadings.length === 0) {
        return { slot, average: null, count: 0 };
      }
      const sum = slotReadings.reduce((acc, curr) => acc + curr.glucose_value, 0);
      return {
        slot,
        average: Math.round((sum / slotReadings.length) * 10) / 10,
        count: slotReadings.length,
      };
    });

    const report: MonthlyReport = {
      month: targetMonth,
      monthName,
      startDate,
      endDate,
      count: summary.count,
      highest: summary.highest,
      lowest: summary.lowest,
      average: summary.average,
      categoryDistribution,
      slotAverages,
    };

    res.json(report);
  } catch (error: any) {
    console.error('Error generating monthly report:', error);
    res.status(500).json({ error: 'Failed to generate monthly report' });
  }
});
