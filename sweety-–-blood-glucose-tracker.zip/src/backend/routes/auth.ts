import { Router, Response } from 'express';
import bcrypt from 'bcryptjs';
import { query } from '../db/database.ts';
import { authenticateJWT, generateToken, AuthenticatedRequest } from '../middleware/auth.ts';
import { User } from '../types.ts';

export const authRouter = Router();

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/**
 * POST /api/auth/register
 * Registers a new user with name, email, and password.
 */
authRouter.post('/register', async (req, res): Promise<void> => {
  try {
    const { name, email, password } = req.body;

    // 1. Validation
    if (!name || typeof name !== 'string' || name.trim().length === 0) {
      res.status(400).json({ error: 'Full name is required' });
      return;
    }

    if (!email || typeof email !== 'string' || !EMAIL_REGEX.test(email.trim().toLowerCase())) {
      res.status(400).json({ error: 'A valid email address is required' });
      return;
    }

    if (!password || typeof password !== 'string' || password.length < 6) {
      res.status(400).json({ error: 'Password must be at least 6 characters long' });
      return;
    }

    const trimmedEmail = email.trim().toLowerCase();
    const trimmedName = name.trim();

    // 2. Check for duplicate email
    const existing = await query('SELECT id FROM users WHERE email = $1', [trimmedEmail]);
    if (existing.rows.length > 0) {
      res.status(409).json({ error: 'An account with this email address already exists' });
      return;
    }

    // 3. Hash password using bcrypt
    const saltRounds = 10;
    const passwordHash = await bcrypt.hash(password, saltRounds);

    // 4. Insert user using parameterized SQL query
    const insertResult = await query<User>(
      `INSERT INTO users (name, email, password_hash)
       VALUES ($1, $2, $3)
       RETURNING id, name, email, created_at, updated_at`,
      [trimmedName, trimmedEmail, passwordHash]
    );

    const newUser = insertResult.rows[0];

    // 5. Generate JWT token
    const token = generateToken({
      id: newUser.id,
      email: newUser.email,
      name: newUser.name,
    });

    res.status(201).json({
      message: 'Account successfully registered',
      user: newUser,
      token,
    });
  } catch (error: any) {
    console.error('Error during registration:', error);
    res.status(500).json({ error: 'Internal server error during registration' });
  }
});

/**
 * POST /api/auth/login
 * Authenticates user credentials and issues a JWT token.
 */
authRouter.post('/login', async (req, res): Promise<void> => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      res.status(400).json({ error: 'Email and password are both required' });
      return;
    }

    const trimmedEmail = String(email).trim().toLowerCase();

    // 1. Fetch user by email with parameterized SQL query
    const result = await query(
      `SELECT id, name, email, password_hash, created_at, updated_at
       FROM users WHERE email = $1`,
      [trimmedEmail]
    );

    if (result.rows.length === 0) {
      res.status(401).json({ error: 'Invalid email or password' });
      return;
    }

    const userRecord = result.rows[0];

    // 2. Verify password with bcrypt
    const passwordMatch = await bcrypt.compare(password, userRecord.password_hash);
    if (!passwordMatch) {
      res.status(401).json({ error: 'Invalid email or password' });
      return;
    }

    // 3. Generate JWT token
    const token = generateToken({
      id: userRecord.id,
      email: userRecord.email,
      name: userRecord.name,
    });

    const user: User = {
      id: userRecord.id,
      name: userRecord.name,
      email: userRecord.email,
      created_at: userRecord.created_at,
      updated_at: userRecord.updated_at,
    };

    res.json({
      message: 'Login successful',
      user,
      token,
    });
  } catch (error: any) {
    console.error('Error during login:', error);
    res.status(500).json({ error: 'Internal server error during login' });
  }
});

/**
 * GET /api/auth/me
 * Retrieves the authenticated user's profile.
 */
authRouter.get('/me', authenticateJWT, async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.id;
    const result = await query<User>(
      'SELECT id, name, email, created_at, updated_at FROM users WHERE id = $1',
      [userId]
    );

    if (result.rows.length === 0) {
      res.status(404).json({ error: 'User not found' });
      return;
    }

    res.json({ user: result.rows[0] });
  } catch (error: any) {
    console.error('Error fetching user profile:', error);
    res.status(500).json({ error: 'Failed to retrieve profile' });
  }
});
