import { Router, Response } from 'express';
import { query } from '../db/database.ts';
import { authenticateJWT, AuthenticatedRequest } from '../middleware/auth.ts';
import { PERMITTED_SLOTS, TimeSlot, GlucoseReading } from '../types.ts';

export const readingsRouter = Router();

// Protect all readings routes with JWT authentication
readingsRouter.use(authenticateJWT);

/**
 * Validates date string format (YYYY-MM-DD) and checks for future dates.
 */
function validateReadingDate(dateStr: string): { valid: boolean; error?: string } {
  if (!dateStr || typeof dateStr !== 'string') {
    return { valid: false, error: 'Date is required and must be in YYYY-MM-DD format' };
  }

  const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
  if (!dateRegex.test(dateStr)) {
    return { valid: false, error: 'Date must be formatted as YYYY-MM-DD' };
  }

  const parsedDate = new Date(dateStr + 'T00:00:00Z');
  if (isNaN(parsedDate.getTime())) {
    return { valid: false, error: 'Invalid calendar date' };
  }

  // Get current date string in YYYY-MM-DD
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];

  if (dateStr > todayStr) {
    return { valid: false, error: 'Future dates are not allowed' };
  }

  return { valid: true };
}

/**
 * Validates glucose reading payload according to clinical & assessment rules.
 */
function validateReadingPayload(body: any): { valid: boolean; error?: string; data?: { value: number; slot: TimeSlot; date: string; notes?: string } } {
  const { glucose_value, time_slot, reading_date, notes } = body;

  // 1. Glucose value validation
  if (glucose_value === undefined || glucose_value === null || glucose_value === '') {
    return { valid: false, error: 'Glucose value is required' };
  }

  const numValue = Number(glucose_value);
  if (isNaN(numValue) || !Number.isInteger(numValue)) {
    return { valid: false, error: 'Glucose value must be a whole number (integer)' };
  }

  if (numValue < 40 || numValue > 600) {
    return { valid: false, error: 'Glucose value must be between 40 and 600 mg/dl' };
  }

  // 2. Time slot validation
  if (!time_slot || typeof time_slot !== 'string') {
    return { valid: false, error: 'Time slot is required' };
  }

  if (!PERMITTED_SLOTS.includes(time_slot as TimeSlot)) {
    return {
      valid: false,
      error: `Invalid time slot. Permitted slots are: ${PERMITTED_SLOTS.join(', ')}`,
    };
  }

  // 3. Date validation
  const dateValidation = validateReadingDate(reading_date);
  if (!dateValidation.valid) {
    return { valid: false, error: dateValidation.error };
  }

  return {
    valid: true,
    data: {
      value: numValue,
      slot: time_slot as TimeSlot,
      date: reading_date,
      notes: typeof notes === 'string' ? notes.trim() : undefined,
    },
  };
}

/**
 * Helper to normalize date to YYYY-MM-DD string from Postgres DATE column
 */
function normalizeDate(val: any): string {
  if (!val) return '';
  if (typeof val === 'string') {
    return val.split('T')[0];
  }
  if (val instanceof Date) {
    return val.toISOString().split('T')[0];
  }
  return String(val);
}

/**
 * GET /api/readings
 * Fetch user's readings with optional filters (date, month, startDate, endDate).
 */
readingsRouter.get('/', async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.id;
    const { date, month, startDate, endDate, slot } = req.query;

    let queryText = `
      SELECT id, user_id, reading_date, time_slot, glucose_value, notes, created_at, updated_at
      FROM glucose_readings
      WHERE user_id = $1
    `;
    const params: any[] = [userId];

    if (date && typeof date === 'string') {
      params.push(date);
      queryText += ` AND reading_date = $${params.length}`;
    } else if (month && typeof month === 'string') {
      // month format: YYYY-MM
      const startOfMonth = `${month}-01`;
      // calculate end of month
      const parts = month.split('-');
      const year = parseInt(parts[0], 10);
      const m = parseInt(parts[1], 10);
      const lastDay = new Date(year, m, 0).getDate();
      const endOfMonth = `${month}-${String(lastDay).padStart(2, '0')}`;

      params.push(startOfMonth, endOfMonth);
      queryText += ` AND reading_date >= $${params.length - 1} AND reading_date <= $${params.length}`;
    } else if (startDate && endDate && typeof startDate === 'string' && typeof endDate === 'string') {
      params.push(startDate, endDate);
      queryText += ` AND reading_date >= $${params.length - 1} AND reading_date <= $${params.length}`;
    }

    if (slot && typeof slot === 'string' && PERMITTED_SLOTS.includes(slot as TimeSlot)) {
      params.push(slot);
      queryText += ` AND time_slot = $${params.length}`;
    }

    queryText += ` ORDER BY reading_date DESC, id DESC`;

    const result = await query<GlucoseReading>(queryText, params);

    const formattedReadings = result.rows.map(r => ({
      ...r,
      reading_date: normalizeDate(r.reading_date),
    }));

    res.json({ readings: formattedReadings });
  } catch (error: any) {
    console.error('Error fetching glucose readings:', error);
    res.status(500).json({ error: 'Failed to retrieve glucose readings' });
  }
});

/**
 * POST /api/readings
 * Adds a new blood glucose reading.
 * Enforces:
 * - 40 - 600 whole number
 * - Permitted slot
 * - Non-future date
 * - One reading per slot per day
 * - Maximum four readings per day
 */
readingsRouter.post('/', async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.id;
    const validation = validateReadingPayload(req.body);

    if (!validation.valid || !validation.data) {
      res.status(400).json({ error: validation.error });
      return;
    }

    const { value, slot, date, notes } = validation.data;

    // Check duplicate slot for this user on this day
    const existingSlot = await query(
      `SELECT id FROM glucose_readings WHERE user_id = $1 AND reading_date = $2 AND time_slot = $3`,
      [userId, date, slot]
    );

    if (existingSlot.rows.length > 0) {
      res.status(409).json({
        error: `A reading for slot "${slot}" already exists on ${date}. Only one reading per slot per day is allowed.`,
      });
      return;
    }

    // Check daily limit (maximum four readings per day)
    const dayCountResult = await query(
      `SELECT COUNT(*) as count FROM glucose_readings WHERE user_id = $1 AND reading_date = $2`,
      [userId, date]
    );
    const dayCount = parseInt(dayCountResult.rows[0].count, 10);
    if (dayCount >= 4) {
      res.status(400).json({
        error: 'Maximum of four readings per day reached for this date.',
      });
      return;
    }

    // Insert new reading using parameterized query
    const insertResult = await query<GlucoseReading>(
      `INSERT INTO glucose_readings (user_id, reading_date, time_slot, glucose_value, notes)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id, user_id, reading_date, time_slot, glucose_value, notes, created_at, updated_at`,
      [userId, date, slot, value, notes || null]
    );

    const createdReading = {
      ...insertResult.rows[0],
      reading_date: normalizeDate(insertResult.rows[0].reading_date),
    };

    res.status(201).json({
      message: 'Glucose reading recorded successfully',
      reading: createdReading,
    });
  } catch (error: any) {
    if (error.code === '23505') {
      // PostgreSQL unique constraint violation
      res.status(409).json({ error: 'A reading for this time slot on this date already exists.' });
      return;
    }
    console.error('Error recording glucose reading:', error);
    res.status(500).json({ error: 'Internal server error while saving reading' });
  }
});

/**
 * PUT /api/readings/:id
 * Updates an existing glucose reading.
 * Enforces user data isolation and validation rules.
 */
readingsRouter.put('/:id', async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.id;
    const readingId = parseInt(req.params.id, 10);

    if (isNaN(readingId)) {
      res.status(400).json({ error: 'Invalid reading ID' });
      return;
    }

    // Verify ownership and existence
    const existing = await query<GlucoseReading>(
      'SELECT id, user_id, reading_date, time_slot FROM glucose_readings WHERE id = $1 AND user_id = $2',
      [readingId, userId]
    );

    if (existing.rows.length === 0) {
      res.status(404).json({ error: 'Reading not found or you do not have permission to modify it' });
      return;
    }

    const current = existing.rows[0];
    const validation = validateReadingPayload(req.body);

    if (!validation.valid || !validation.data) {
      res.status(400).json({ error: validation.error });
      return;
    }

    const { value, slot, date, notes } = validation.data;
    const currentDateStr = normalizeDate(current.reading_date);

    // If slot or date changed, check conflict with another reading
    if (slot !== current.time_slot || date !== currentDateStr) {
      const conflict = await query(
        `SELECT id FROM glucose_readings
         WHERE user_id = $1 AND reading_date = $2 AND time_slot = $3 AND id != $4`,
        [userId, date, slot, readingId]
      );

      if (conflict.rows.length > 0) {
        res.status(409).json({
          error: `Another reading for slot "${slot}" already exists on ${date}.`,
        });
        return;
      }
    }

    // Execute update parameterized query
    const updateResult = await query<GlucoseReading>(
      `UPDATE glucose_readings
       SET reading_date = $1, time_slot = $2, glucose_value = $3, notes = $4, updated_at = CURRENT_TIMESTAMP
       WHERE id = $5 AND user_id = $6
       RETURNING id, user_id, reading_date, time_slot, glucose_value, notes, created_at, updated_at`,
      [date, slot, value, notes || null, readingId, userId]
    );

    const updatedReading = {
      ...updateResult.rows[0],
      reading_date: normalizeDate(updateResult.rows[0].reading_date),
    };

    res.json({
      message: 'Glucose reading updated successfully',
      reading: updatedReading,
    });
  } catch (error: any) {
    if (error.code === '23505') {
      res.status(409).json({ error: 'A reading for this time slot on this date already exists.' });
      return;
    }
    console.error('Error updating glucose reading:', error);
    res.status(500).json({ error: 'Failed to update glucose reading' });
  }
});

/**
 * DELETE /api/readings/:id
 * Deletes a glucose reading.
 * Enforces user data isolation.
 */
readingsRouter.delete('/:id', async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.id;
    const readingId = parseInt(req.params.id, 10);

    if (isNaN(readingId)) {
      res.status(400).json({ error: 'Invalid reading ID' });
      return;
    }

    // Delete reading only if owned by authenticated user
    const result = await query(
      'DELETE FROM glucose_readings WHERE id = $1 AND user_id = $2 RETURNING id',
      [readingId, userId]
    );

    if (result.rows.length === 0) {
      res.status(404).json({ error: 'Reading not found or you do not have permission to delete it' });
      return;
    }

    res.json({
      message: 'Reading successfully deleted',
      id: readingId,
    });
  } catch (error: any) {
    console.error('Error deleting glucose reading:', error);
    res.status(500).json({ error: 'Failed to delete glucose reading' });
  }
});
