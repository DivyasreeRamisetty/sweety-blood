import { Router, Response } from 'express';
import { GoogleGenAI } from '@google/genai';
import { query } from '../db/database.ts';
import { authenticateJWT, AuthenticatedRequest } from '../middleware/auth.ts';
import { GlucoseReading } from '../types.ts';

export const aiRouter = Router();

aiRouter.use(authenticateJWT);

/**
 * Generate heuristic clinical observations if Gemini is unavailable
 */
function generateRuleBasedInsights(readings: GlucoseReading[]) {
  if (readings.length === 0) {
    return {
      summary: 'No readings recorded yet. Start logging readings across meal slots to unlock clinical pattern analysis.',
      highlights: ['Log fasting and post-meal readings to establish your baseline.'],
      recommendations: [
        'Check fasting glucose within 15-30 minutes of waking.',
        'Test 2 hours post-meal to evaluate carbohydrate response.',
      ],
      glycemicStability: 'Insufficient Data',
    };
  }

  const values = readings.map(r => r.glucose_value);
  const avg = Math.round(values.reduce((a, b) => a + b, 0) / values.length);
  const highest = Math.max(...values);
  const lowest = Math.min(...values);

  const fastingReadings = readings.filter(r => r.time_slot === 'Morning (fasting)');
  const fastingAvg = fastingReadings.length > 0
    ? Math.round(fastingReadings.reduce((a, b) => a + b.glucose_value, 0) / fastingReadings.length)
    : null;

  const highlights: string[] = [];
  const recommendations: string[] = [];

  if (lowest < 70) {
    highlights.push(`Alert: Hypoglycemic event detected (${lowest} mg/dl). Keep fast-acting carbohydrates on hand.`);
    recommendations.push('Review medication timing and carbohydrate intake with your physician.');
  }

  if (fastingAvg !== null) {
    if (fastingAvg <= 100) {
      highlights.push(`Fasting glucose averages ${fastingAvg} mg/dl, within optimal clinical fasting range (<100 mg/dl).`);
    } else if (fastingAvg <= 125) {
      highlights.push(`Fasting glucose averages ${fastingAvg} mg/dl (pre-diabetic threshold: 100-125 mg/dl).`);
      recommendations.push('Consider evening snack adjustments to curb overnight hepatic glucose output.');
    } else {
      highlights.push(`Fasting glucose averages ${fastingAvg} mg/dl, exceeding target fasting range (>126 mg/dl).`);
    }
  }

  const postMealReadings = readings.filter(r => r.time_slot.startsWith('After'));
  if (postMealReadings.length > 0) {
    const postMealAvg = Math.round(postMealReadings.reduce((a, b) => a + b.glucose_value, 0) / postMealReadings.length);
    if (postMealAvg <= 140) {
      highlights.push(`Postprandial (post-meal) readings average ${postMealAvg} mg/dl, demonstrating excellent glycemic control.`);
    } else {
      highlights.push(`Postprandial readings average ${postMealAvg} mg/dl (clinical goal <140 mg/dl).`);
      recommendations.push('A 15-minute post-meal walk significantly blunts glycemic excursion.');
    }
  }

  return {
    summary: `Based on your recent ${readings.length} readings, your average glucose is ${avg} mg/dl (range: ${lowest} - ${highest} mg/dl).`,
    highlights,
    recommendations: recommendations.length > 0 ? recommendations : [
      'Maintain regular testing intervals across all four daily slots.',
      'Hydrate with water throughout the day to support kidney filtration.',
    ],
    glycemicStability: avg <= 130 ? 'Stable' : avg <= 160 ? 'Moderate Excursions' : 'High Excursions',
  };
}

/**
 * POST /api/ai/insights
 * Returns AI clinical pattern analysis and lifestyle recommendations.
 */
aiRouter.post('/insights', async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.id;

    // Fetch user's last 30 readings
    const result = await query<GlucoseReading>(
      `SELECT id, user_id, reading_date, time_slot, glucose_value, notes, created_at
       FROM glucose_readings
       WHERE user_id = $1
       ORDER BY reading_date DESC, id DESC
       LIMIT 30`,
      [userId]
    );

    const readings = result.rows;

    if (readings.length === 0) {
      res.json(generateRuleBasedInsights([]));
      return;
    }

    const apiKey = process.env.GEMINI_API_KEY;

    // If no key or placeholder, return robust rule-based clinical analysis
    if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
      res.json(generateRuleBasedInsights(readings));
      return;
    }

    try {
      const ai = new GoogleGenAI({ apiKey });
      const prompt = `
You are a clinical endocrinology advisor for the Sweety Blood Glucose Tracker app.
Analyze the following patient blood glucose readings (measured in mg/dl):
${JSON.stringify(
  readings.map(r => ({
    date: r.reading_date,
    slot: r.time_slot,
    value: r.glucose_value,
    notes: r.notes,
  })),
  null,
  2
)}

Context:
- Normal fasting glucose: 70 - 99 mg/dl
- Normal 2-hour postprandial glucose: < 140 mg/dl
- Hypoglycemia: < 70 mg/dl
- Hyperglycemia: > 180 mg/dl

Return a JSON object strictly matching this schema:
{
  "summary": "1-2 sentence high-level overview of glycemic trends",
  "highlights": ["3 concise bullet points identifying patterns like dawn phenomenon, post-lunch spikes, or stability"],
  "recommendations": ["2-3 practical, actionable, evidence-based lifestyle or dietary suggestions"],
  "glycemicStability": "Stable" | "Moderate Excursions" | "High Excursions"
}
Do not include markdown ticks, just raw JSON. Include medical disclaimer understanding that this is for educational tracking.
`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.2,
        },
      });

      const text = response.text?.trim() || '';
      try {
        const parsed = JSON.parse(text);
        res.json(parsed);
      } catch (parseErr) {
        res.json(generateRuleBasedInsights(readings));
      }
    } catch (aiErr) {
      console.warn('Gemini API call failed, falling back to rule-based engine:', aiErr);
      res.json(generateRuleBasedInsights(readings));
    }
  } catch (error: any) {
    console.error('Error generating AI insights:', error);
    res.status(500).json({ error: 'Failed to generate insights' });
  }
});
