-- Sweety – Blood Glucose Tracker
-- Database Migration: 001_initial_schema.sql
-- Dialect: PostgreSQL

-- 1. Users Table
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 2. Glucose Readings Table
CREATE TABLE IF NOT EXISTS glucose_readings (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reading_date DATE NOT NULL,
  time_slot VARCHAR(50) NOT NULL,
  glucose_value INTEGER NOT NULL CHECK (glucose_value >= 40 AND glucose_value <= 600),
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  -- Enforce business rule: only one reading per slot per day per user
  CONSTRAINT unique_user_date_slot UNIQUE (user_id, reading_date, time_slot)
);

-- 3. Indexes for fast query lookup & reporting
CREATE INDEX IF NOT EXISTS idx_readings_user_date ON glucose_readings(user_id, reading_date);
CREATE INDEX IF NOT EXISTS idx_readings_user_slot ON glucose_readings(user_id, time_slot);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
