import { PGlite } from '@electric-sql/pglite';
import pg from 'pg';
import path from 'path';
import fs from 'fs';

export interface QueryResult<T = any> {
  rows: T[];
  rowCount: number;
}

export interface DatabaseClient {
  query<T = any>(sql: string, params?: any[]): Promise<QueryResult<T>>;
  exec(sql: string): Promise<void>;
  close(): Promise<void>;
}

let dbInstance: DatabaseClient | null = null;
let initPromise: Promise<DatabaseClient> | null = null;

/**
 * PostgreSQL Schema Migration DDL
 */
const INITIAL_SCHEMA_SQL = `
-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create glucose_readings table
CREATE TABLE IF NOT EXISTS glucose_readings (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reading_date DATE NOT NULL,
  time_slot VARCHAR(50) NOT NULL,
  glucose_value INTEGER NOT NULL CHECK (glucose_value >= 40 AND glucose_value <= 600),
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT unique_user_date_slot UNIQUE (user_id, reading_date, time_slot)
);

-- Create performance indexes
CREATE INDEX IF NOT EXISTS idx_readings_user_date ON glucose_readings(user_id, reading_date);
CREATE INDEX IF NOT EXISTS idx_readings_user_slot ON glucose_readings(user_id, time_slot);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
`;

/**
 * Creates and initializes the database connection.
 * Connects to external PostgreSQL via pg.Pool if DATABASE_URL or PGHOST is set,
 * otherwise boots an embedded PostgreSQL engine with @electric-sql/pglite.
 */
export async function getDatabase(): Promise<DatabaseClient> {
  if (dbInstance) return dbInstance;
  if (initPromise) return initPromise;

  initPromise = (async () => {
    const isTest = process.env.NODE_ENV === 'test';
    const databaseUrl = process.env.DATABASE_URL;
    const pgHost = process.env.PGHOST;

    if (databaseUrl || pgHost) {
      // Connect to standard external PostgreSQL
      const pool = new pg.Pool({
        connectionString: databaseUrl,
        host: pgHost,
        port: process.env.PGPORT ? parseInt(process.env.PGPORT, 10) : 5432,
        user: process.env.PGUSER,
        password: process.env.PGPASSWORD,
        database: process.env.PGDATABASE,
        max: 10,
        idleTimeoutMillis: 30000,
      });

      const client: DatabaseClient = {
        async query<T = any>(sql: string, params: any[] = []): Promise<QueryResult<T>> {
          const res = await pool.query(sql, params);
          return {
            rows: res.rows as T[],
            rowCount: res.rowCount ?? res.rows.length,
          };
        },
        async exec(sql: string): Promise<void> {
          await pool.query(sql);
        },
        async close() {
          await pool.end();
          dbInstance = null;
        },
      };

      // Run migrations
      await client.exec(INITIAL_SCHEMA_SQL);
      dbInstance = client;
      console.log('✅ Connected to external PostgreSQL database via pg.Pool');
      return client;
    } else {
      // Use embedded PostgreSQL via @electric-sql/pglite
      const dataDir = isTest
        ? undefined // in-memory for testing
        : path.resolve(process.cwd(), 'data', 'pgdata');

      if (dataDir && !fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      const pglite = new PGlite(dataDir);
      await pglite.waitReady;

      const client: DatabaseClient = {
        async query<T = any>(sql: string, params: any[] = []): Promise<QueryResult<T>> {
          const res = await pglite.query(sql, params);
          return {
            rows: (res.rows || []) as T[],
            rowCount: res.affectedRows ?? res.rows?.length ?? 0,
          };
        },
        async exec(sql: string): Promise<void> {
          await pglite.exec(sql);
        },
        async close() {
          await pglite.close();
          dbInstance = null;
        },
      };

      // Run migrations
      await client.exec(INITIAL_SCHEMA_SQL);
      dbInstance = client;
      console.log(`✅ Initialized PostgreSQL engine (${isTest ? 'in-memory test' : 'embedded storage: ./data/pgdata'})`);
      return client;
    }
  })();

  return initPromise;
}

/**
 * Helper to execute a query using the active PostgreSQL client.
 */
export async function query<T = any>(sql: string, params: any[] = []): Promise<QueryResult<T>> {
  const db = await getDatabase();
  return db.query<T>(sql, params);
}
