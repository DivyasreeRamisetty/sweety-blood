import React, { useState, useEffect } from 'react';
import { MonthToDateReport, TimeSlot } from '../types/client.ts';
import { api } from '../services/api.ts';
import {
  Calendar,
  Activity,
  ArrowDownRight,
  ArrowUpRight,
  Clock,
  TrendingUp,
  AlertCircle,
  BarChart3,
} from 'lucide-react';

interface MonthToDateReportViewProps {
  onOpenAddModal: () => void;
}

export const MonthToDateReportView: React.FC<MonthToDateReportViewProps> = ({ onOpenAddModal }) => {
  const todayStr = new Date().toISOString().split('T')[0];
  const [selectedDate, setSelectedDate] = useState<string>(todayStr);
  const [report, setReport] = useState<MonthToDateReport | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchMTDReport = async (date: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await api.getMonthToDateReport(date);
      setReport(data);
    } catch (err: any) {
      setError(err.message || 'Failed to load month-to-date report');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchMTDReport(selectedDate);
  }, [selectedDate]);

  return (
    <div className="space-y-6">
      {/* Header & Date Scope */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-semibold text-teal-600 uppercase tracking-wider flex items-center gap-1.5 mb-1">
            <TrendingUp className="w-3.5 h-3.5" />
            Cumulative Report
          </span>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
            Month-to-Date (MTD) Report
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Scope:{' '}
            <strong className="text-slate-800 font-semibold font-mono">
              {report?.startDate || '—'}
            </strong>{' '}
            through{' '}
            <strong className="text-slate-800 font-semibold font-mono">
              {report?.endDate || selectedDate}
            </strong>
          </p>
        </div>

        <div className="flex items-center gap-2">
          <label className="text-xs text-slate-500 font-medium whitespace-nowrap">
            Selected Date:
          </label>
          <input
            type="date"
            max={todayStr}
            value={selectedDate}
            onChange={e => setSelectedDate(e.target.value)}
            className="px-3.5 py-2 border border-slate-200 rounded-xl text-xs font-mono font-semibold text-slate-800 bg-white focus:outline-hidden focus:border-teal-600"
          />
        </div>
      </div>

      {error && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* KPI Aggregate Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Average */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>MTD Average</span>
            <Activity className="w-4 h-4 text-teal-600" />
          </div>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
              {report?.average !== null && report?.average !== undefined
                ? report.average.toFixed(1)
                : '—'}
            </span>
            <span className="text-xs text-slate-400">mg/dL</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">First day of month to date</p>
        </div>

        {/* Highest */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>MTD Highest</span>
            <ArrowUpRight className="w-4 h-4 text-purple-600" />
          </div>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
              {report?.highest ?? '—'}
            </span>
            <span className="text-xs text-slate-400">mg/dL</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Maximum value in range</p>
        </div>

        {/* Lowest */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>MTD Lowest</span>
            <ArrowDownRight className="w-4 h-4 text-teal-600" />
          </div>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
              {report?.lowest ?? '—'}
            </span>
            <span className="text-xs text-slate-400">mg/dL</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Minimum value in range</p>
        </div>

        {/* Count */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>Total MTD Readings</span>
            <Clock className="w-4 h-4 text-slate-600" />
          </div>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
              {report?.count ?? 0}
            </span>
            <span className="text-xs text-slate-400">readings</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Cumulative entries</p>
        </div>
      </div>

      {isLoading ? (
        <div className="bg-white rounded-2xl p-12 text-center text-slate-400 text-xs border border-slate-200">
          <div className="w-6 h-6 border-2 border-teal-600 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
          Calculating Month-to-Date statistics...
        </div>
      ) : !report || report.count === 0 ? (
        /* Friendly Empty State */
        <div className="bg-white rounded-2xl p-12 border border-slate-200/90 shadow-2xs text-center">
          <div className="w-14 h-14 rounded-2xl bg-teal-50 text-teal-600 flex items-center justify-center mx-auto mb-3">
            <BarChart3 className="w-7 h-7" />
          </div>
          <h3 className="text-sm font-bold text-slate-900">No readings found for this month-to-date period</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 leading-relaxed">
            There are no glucose readings logged between {report?.startDate} and {selectedDate}. Log a reading to start tracking your monthly trajectory.
          </p>
          <div className="mt-4">
            <button
              onClick={onOpenAddModal}
              className="px-4 py-2 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-xl transition-colors cursor-pointer"
            >
              Log a Reading
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Slot Breakdown Cards */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-2xs">
            <h2 className="text-base font-bold text-slate-900 mb-1">Averages by Meal Slot</h2>
            <p className="text-xs text-slate-500 mb-4">
              Breakdown of glycemic control across all 4 daily slots throughout this month-to-date
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {report.slotAverages.map(slotItem => {
                const hasData = slotItem.average !== null;
                return (
                  <div
                    key={slotItem.slot}
                    className="p-4 rounded-xl border border-slate-100 bg-slate-50/50 flex flex-col justify-between"
                  >
                    <div>
                      <span className="text-xs font-semibold text-slate-700">{slotItem.slot}</span>
                      <div className="flex items-baseline gap-1 mt-2">
                        <span className="text-2xl font-extrabold text-slate-900 font-mono tabular-nums">
                          {hasData ? slotItem.average?.toFixed(1) : '—'}
                        </span>
                        <span className="text-xs text-slate-400">mg/dL</span>
                      </div>
                    </div>
                    <span className="text-[11px] text-slate-400 mt-2">
                      {slotItem.count} {slotItem.count === 1 ? 'reading' : 'readings'}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Daily Trend List */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-2xs">
            <h2 className="text-base font-bold text-slate-900 mb-1">Daily Average Trends</h2>
            <p className="text-xs text-slate-500 mb-4">
              Day-by-day glycemic trajectory across {report.dailyTrends.length} active recording days
            </p>

            <div className="space-y-2">
              {report.dailyTrends.map(day => {
                const percent = Math.min(100, Math.max(10, ((day.average - 40) / 200) * 100));
                return (
                  <div
                    key={day.date}
                    className="p-3 rounded-xl border border-slate-100 hover:border-slate-200 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                  >
                    <div className="flex items-center gap-3 w-44 shrink-0">
                      <span className="font-mono text-xs font-bold text-slate-800">{day.date}</span>
                      <span className="text-[10px] text-slate-400">({day.count} slots)</span>
                    </div>

                    <div className="flex-1 flex items-center gap-3">
                      <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all ${
                            day.average < 70
                              ? 'bg-amber-500'
                              : day.average <= 140
                              ? 'bg-teal-500'
                              : day.average <= 180
                              ? 'bg-purple-500'
                              : 'bg-rose-500'
                          }`}
                          style={{ width: `${percent}%` }}
                        ></div>
                      </div>
                      <span className="font-mono text-xs font-bold text-slate-900 tabular-nums shrink-0 w-16 text-right">
                        {day.average.toFixed(1)} <span className="text-[10px] text-slate-400 font-normal">mg/dl</span>
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
