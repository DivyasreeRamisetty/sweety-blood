import React, { useState, useEffect } from 'react';
import { MonthlyReport } from '../types/client.ts';
import { api } from '../services/api.ts';
import {
  Calendar,
  Activity,
  ArrowDownRight,
  ArrowUpRight,
  Clock,
  PieChart,
  AlertCircle,
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
} from 'lucide-react';

interface MonthlyReportViewProps {
  onOpenAddModal: () => void;
}

export const MonthlyReportView: React.FC<MonthlyReportViewProps> = ({ onOpenAddModal }) => {
  // Calculate default previous calendar month
  const getPreviousMonthKey = () => {
    const now = new Date();
    let y = now.getFullYear();
    let m = now.getMonth(); // 0-11, so current month index is previous month number (1-12)
    if (m === 0) {
      m = 12;
      y -= 1;
    }
    return `${y}-${String(m).padStart(2, '0')}`;
  };

  const [selectedMonth, setSelectedMonth] = useState<string>(getPreviousMonthKey());
  const [report, setReport] = useState<MonthlyReport | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchMonthlyReport = async (monthKey: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await api.getMonthlyReport(monthKey);
      setReport(data);
    } catch (err: any) {
      setError(err.message || 'Failed to load monthly report');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchMonthlyReport(selectedMonth);
  }, [selectedMonth]);

  const handlePrevMonth = () => {
    const [yStr, mStr] = selectedMonth.split('-');
    let y = parseInt(yStr, 10);
    let m = parseInt(mStr, 10) - 1;
    if (m < 1) {
      m = 12;
      y -= 1;
    }
    setSelectedMonth(`${y}-${String(m).padStart(2, '0')}`);
  };

  const handleNextMonth = () => {
    const [yStr, mStr] = selectedMonth.split('-');
    let y = parseInt(yStr, 10);
    let m = parseInt(mStr, 10) + 1;
    if (m > 12) {
      m = 1;
      y += 1;
    }
    setSelectedMonth(`${y}-${String(m).padStart(2, '0')}`);
  };

  return (
    <div className="space-y-6">
      {/* Month Navigation & Scope Header */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-semibold text-purple-700 uppercase tracking-wider flex items-center gap-1.5 mb-1">
            <Calendar className="w-3.5 h-3.5" />
            Monthly Calendar Audit
          </span>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
            Monthly Report: {report?.monthName || selectedMonth}
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Full calendar month audit from{' '}
            <strong className="text-slate-800 font-semibold font-mono">{report?.startDate || '—'}</strong>{' '}
            to{' '}
            <strong className="text-slate-800 font-semibold font-mono">{report?.endDate || '—'}</strong>
          </p>
        </div>

        {/* Month Picker Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={handlePrevMonth}
            className="p-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 hover:text-slate-900 transition-colors cursor-pointer"
            title="Previous Month"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <input
            type="month"
            value={selectedMonth}
            onChange={e => setSelectedMonth(e.target.value)}
            className="px-3.5 py-2 border border-slate-200 rounded-xl text-xs font-mono font-semibold text-slate-800 bg-white focus:outline-hidden focus:border-purple-600"
          />

          <button
            onClick={handleNextMonth}
            className="p-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 hover:text-slate-900 transition-colors cursor-pointer"
            title="Next Month"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* KPI Aggregate Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Average */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>Monthly Average</span>
            <Activity className="w-4 h-4 text-purple-600" />
          </div>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
              {report?.average !== null && report?.average !== undefined
                ? report.average.toFixed(1)
                : '—'}
            </span>
            <span className="text-xs text-slate-400">mg/dL</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Entire calendar month</p>
        </div>

        {/* Highest */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>Monthly Peak</span>
            <ArrowUpRight className="w-4 h-4 text-purple-600" />
          </div>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
              {report?.highest ?? '—'}
            </span>
            <span className="text-xs text-slate-400">mg/dL</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Highest recorded peak</p>
        </div>

        {/* Lowest */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>Monthly Minimum</span>
            <ArrowDownRight className="w-4 h-4 text-teal-600" />
          </div>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
              {report?.lowest ?? '—'}
            </span>
            <span className="text-xs text-slate-400">mg/dL</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Lowest recorded value</p>
        </div>

        {/* Count */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>Total Monthly Readings</span>
            <Clock className="w-4 h-4 text-slate-600" />
          </div>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
              {report?.count ?? 0}
            </span>
            <span className="text-xs text-slate-400">readings</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Recorded entries in month</p>
        </div>
      </div>

      {isLoading ? (
        <div className="bg-white rounded-2xl p-12 text-center text-slate-400 text-xs border border-slate-200">
          <div className="w-6 h-6 border-2 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
          Aggregating calendar month report...
        </div>
      ) : !report || report.count === 0 ? (
        /* Friendly Empty State */
        <div className="bg-white rounded-2xl p-12 border border-slate-200/90 shadow-2xs text-center">
          <div className="w-14 h-14 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center mx-auto mb-3">
            <Calendar className="w-7 h-7" />
          </div>
          <h3 className="text-sm font-bold text-slate-900">
            No readings found for {report?.monthName || selectedMonth}
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 leading-relaxed">
            There were no glucose readings logged during this calendar month. You can select another month from the picker above or record new entries.
          </p>
          <div className="mt-4">
            <button
              onClick={onOpenAddModal}
              className="px-4 py-2 text-xs font-semibold text-white bg-purple-600 hover:bg-purple-700 rounded-xl transition-colors cursor-pointer"
            >
              Log a Reading
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* ADA Glycemic Distribution Card */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-2xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-1">
                <h2 className="text-base font-bold text-slate-900">Glycemic Range Distribution</h2>
                <span className="text-[11px] text-teal-700 font-semibold bg-teal-50 px-2 py-0.5 rounded-md border border-teal-100">
                  ADA Standards
                </span>
              </div>
              <p className="text-xs text-slate-500 mb-5">
                Proportion of readings categorized by American Diabetes Association clinical thresholds
              </p>

              <div className="space-y-3.5">
                {/* Normal / In Target (70 - 140) */}
                <div>
                  <div className="flex items-center justify-between text-xs font-medium mb-1">
                    <span className="text-slate-700 flex items-center gap-1.5 font-semibold">
                      <span className="w-2.5 h-2.5 rounded-full bg-teal-500"></span>
                      In Target (70 – 140 mg/dl)
                    </span>
                    <span className="font-mono font-bold text-slate-900">
                      {report.categoryDistribution.normal}{' '}
                      <span className="text-slate-400 font-normal">
                        ({Math.round((report.categoryDistribution.normal / report.count) * 100)}%)
                      </span>
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-teal-500 h-full rounded-full"
                      style={{ width: `${(report.categoryDistribution.normal / report.count) * 100}%` }}
                    ></div>
                  </div>
                </div>

                {/* Elevated (141 - 180) */}
                <div>
                  <div className="flex items-center justify-between text-xs font-medium mb-1">
                    <span className="text-slate-700 flex items-center gap-1.5 font-semibold">
                      <span className="w-2.5 h-2.5 rounded-full bg-purple-500"></span>
                      Elevated (141 – 180 mg/dl)
                    </span>
                    <span className="font-mono font-bold text-slate-900">
                      {report.categoryDistribution.elevated}{' '}
                      <span className="text-slate-400 font-normal">
                        ({Math.round((report.categoryDistribution.elevated / report.count) * 100)}%)
                      </span>
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-purple-500 h-full rounded-full"
                      style={{ width: `${(report.categoryDistribution.elevated / report.count) * 100}%` }}
                    ></div>
                  </div>
                </div>

                {/* Hypoglycemia (< 70) */}
                <div>
                  <div className="flex items-center justify-between text-xs font-medium mb-1">
                    <span className="text-slate-700 flex items-center gap-1.5 font-semibold">
                      <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
                      Low / Hypoglycemia (&lt; 70 mg/dl)
                    </span>
                    <span className="font-mono font-bold text-slate-900">
                      {report.categoryDistribution.hypoglycemia}{' '}
                      <span className="text-slate-400 font-normal">
                        ({Math.round((report.categoryDistribution.hypoglycemia / report.count) * 100)}%)
                      </span>
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-amber-500 h-full rounded-full"
                      style={{ width: `${(report.categoryDistribution.hypoglycemia / report.count) * 100}%` }}
                    ></div>
                  </div>
                </div>

                {/* Hyperglycemia (> 180) */}
                <div>
                  <div className="flex items-center justify-between text-xs font-medium mb-1">
                    <span className="text-slate-700 flex items-center gap-1.5 font-semibold">
                      <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
                      High / Hyperglycemia (&gt; 180 mg/dl)
                    </span>
                    <span className="font-mono font-bold text-slate-900">
                      {report.categoryDistribution.high}{' '}
                      <span className="text-slate-400 font-normal">
                        ({Math.round((report.categoryDistribution.high / report.count) * 100)}%)
                      </span>
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-rose-500 h-full rounded-full"
                      style={{ width: `${(report.categoryDistribution.high / report.count) * 100}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 p-3 bg-slate-50 rounded-xl text-[11px] text-slate-500 border border-slate-100">
              Clinical target: Maintain $\ge 70\%$ of readings within the 70–140 mg/dl target window.
            </div>
          </div>

          {/* Slot Breakdown Card */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-2xs flex flex-col justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900 mb-1">Slot Performance</h2>
              <p className="text-xs text-slate-500 mb-5">
                Monthly average breakdown for each of the 4 permitted meal slots
              </p>

              <div className="space-y-3">
                {report.slotAverages.map(slotItem => {
                  const hasData = slotItem.average !== null;
                  return (
                    <div
                      key={slotItem.slot}
                      className="p-3.5 rounded-xl border border-slate-100 bg-slate-50/50 flex items-center justify-between"
                    >
                      <div>
                        <h4 className="text-xs font-bold text-slate-800">{slotItem.slot}</h4>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          {slotItem.count} {slotItem.count === 1 ? 'reading' : 'readings'} recorded
                        </p>
                      </div>

                      <div className="text-right">
                        <span className="text-lg font-extrabold text-slate-900 font-mono tabular-nums">
                          {hasData ? slotItem.average?.toFixed(1) : '—'}
                        </span>
                        <span className="text-[10px] text-slate-400 ml-1">mg/dL</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="mt-6 p-3 bg-purple-50/60 rounded-xl text-[11px] text-purple-800 border border-purple-100 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-purple-600 shrink-0" />
              <span>Full compliance with 4-slot daily constraint throughout calendar month.</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
