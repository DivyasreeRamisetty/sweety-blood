import React, { useState, useEffect } from 'react';
import { DailyReport, GlucoseReading, TimeSlot, PERMITTED_SLOTS } from '../types/client.ts';
import { api } from '../services/api.ts';
import {
  Calendar,
  ChevronLeft,
  ChevronRight,
  Activity,
  ArrowDownRight,
  ArrowUpRight,
  Clock,
  Plus,
  Edit2,
  Trash2,
  AlertCircle,
} from 'lucide-react';

interface DailyReportViewProps {
  onOpenAddModal: (slot?: TimeSlot, date?: string) => void;
  onOpenEditModal: (reading: GlucoseReading) => void;
  onOpenDeleteModal: (reading: GlucoseReading) => void;
}

export const DailyReportView: React.FC<DailyReportViewProps> = ({
  onOpenAddModal,
  onOpenEditModal,
  onOpenDeleteModal,
}) => {
  const todayStr = new Date().toISOString().split('T')[0];
  const [selectedDate, setSelectedDate] = useState<string>(todayStr);
  const [report, setReport] = useState<DailyReport | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchDailyReport = async (date: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await api.getDailyReport(date);
      setReport(data);
    } catch (err: any) {
      setError(err.message || 'Failed to load daily report');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDailyReport(selectedDate);
  }, [selectedDate]);

  const handlePrevDay = () => {
    const d = new Date(selectedDate + 'T00:00:00');
    d.setDate(d.getDate() - 1);
    setSelectedDate(d.toISOString().split('T')[0]);
  };

  const handleNextDay = () => {
    const d = new Date(selectedDate + 'T00:00:00');
    d.setDate(d.getDate() + 1);
    const nextStr = d.toISOString().split('T')[0];
    if (nextStr <= todayStr) {
      setSelectedDate(nextStr);
    }
  };

  const getStatusBadge = (val: number) => {
    if (val < 70) return { label: 'Low', color: 'text-amber-700 bg-amber-50 border-amber-200' };
    if (val <= 140) return { label: 'Target', color: 'text-teal-700 bg-teal-50 border-teal-200' };
    if (val <= 180) return { label: 'Elevated', color: 'text-purple-700 bg-purple-50 border-purple-200' };
    return { label: 'High', color: 'text-rose-700 bg-rose-50 border-rose-200' };
  };

  const formattedDisplayDate = new Date(selectedDate + 'T00:00:00').toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  });

  return (
    <div className="space-y-6">
      {/* Date Selector Header */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-semibold text-purple-700 uppercase tracking-wider flex items-center gap-1.5 mb-1">
            <Calendar className="w-3.5 h-3.5" />
            Clinical Report
          </span>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
            Daily Glucose Report
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Showing all 4 meal slots and clinical aggregates for {formattedDisplayDate}
          </p>
        </div>

        {/* Date Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={handlePrevDay}
            className="p-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 hover:text-slate-900 transition-colors cursor-pointer"
            title="Previous Day"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <input
            type="date"
            max={todayStr}
            value={selectedDate}
            onChange={e => setSelectedDate(e.target.value)}
            className="px-3.5 py-2 border border-slate-200 rounded-xl text-xs font-mono font-semibold text-slate-800 bg-white focus:outline-hidden focus:border-purple-600"
          />

          <button
            onClick={handleNextDay}
            disabled={selectedDate >= todayStr}
            className="p-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 hover:text-slate-900 disabled:opacity-40 disabled:pointer-events-none transition-colors cursor-pointer"
            title="Next Day"
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          {selectedDate !== todayStr && (
            <button
              onClick={() => setSelectedDate(todayStr)}
              className="px-3 py-2 text-xs font-semibold text-purple-700 bg-purple-50 hover:bg-purple-100 rounded-xl border border-purple-200 transition-colors cursor-pointer"
            >
              Today
            </button>
          )}
        </div>
      </div>

      {error && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* KPI Aggregate Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Average */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>Average Reading</span>
            <Activity className="w-4 h-4 text-purple-600" />
          </div>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
              {report?.average !== null && report?.average !== undefined
                ? report.average.toFixed(1)
                : '—'}
            </span>
            <span className="text-xs text-slate-400">mg/dL</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Rounded to 1 decimal</p>
        </div>

        {/* Highest */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>Highest Reading</span>
            <ArrowUpRight className="w-4 h-4 text-purple-600" />
          </div>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
              {report?.highest ?? '—'}
            </span>
            <span className="text-xs text-slate-400">mg/dL</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Peak daily measurement</p>
        </div>

        {/* Lowest */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>Lowest Reading</span>
            <ArrowDownRight className="w-4 h-4 text-teal-600" />
          </div>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
              {report?.lowest ?? '—'}
            </span>
            <span className="text-xs text-slate-400">mg/dL</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Lowest recorded value</p>
        </div>

        {/* Count */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>Number of Readings</span>
            <Clock className="w-4 h-4 text-slate-600" />
          </div>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
              {report?.count ?? 0}
            </span>
            <span className="text-xs text-slate-400">/ 4 slots</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Daily completion rate</p>
        </div>
      </div>

      {/* Individual Readings and Slots */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs overflow-hidden">
        <div className="p-5 sm:p-6 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900">Recorded Slots for {selectedDate}</h2>
            <p className="text-xs text-slate-500">
              Ordered in clinical sequence: Morning (fasting) &rarr; After breakfast &rarr; After lunch &rarr; After dinner
            </p>
          </div>
          {report && report.count < 4 && (
            <button
              onClick={() => onOpenAddModal(undefined, selectedDate)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-purple-700 bg-purple-50 hover:bg-purple-100 border border-purple-200 rounded-lg transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Missing Slot</span>
            </button>
          )}
        </div>

        {isLoading ? (
          <div className="p-12 text-center text-slate-400 text-xs">
            <div className="w-6 h-6 border-2 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
            Loading daily report...
          </div>
        ) : !report || report.readings.length === 0 ? (
          /* Friendly Empty State */
          <div className="p-12 text-center">
            <div className="w-14 h-14 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center mx-auto mb-3">
              <Calendar className="w-7 h-7" />
            </div>
            <h3 className="text-sm font-bold text-slate-900">
              No readings recorded for {formattedDisplayDate}
            </h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 leading-relaxed">
              Tracking consistent readings across breakfast, lunch, and dinner helps establish your glycemic baseline.
            </p>
            <div className="mt-4">
              <button
                onClick={() => onOpenAddModal('Morning (fasting)', selectedDate)}
                className="px-4 py-2 text-xs font-semibold text-white bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700 rounded-xl shadow-xs shadow-purple-200 transition-all cursor-pointer inline-flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Log Reading for {selectedDate}</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {report.readings.map(reading => {
              const badge = getStatusBadge(reading.glucose_value);
              return (
                <div
                  key={reading.id}
                  className="p-5 sm:px-6 hover:bg-slate-50/70 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="flex items-start sm:items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-purple-50 text-purple-700 flex flex-col items-center justify-center font-mono shrink-0">
                      <span className="text-base font-extrabold leading-none">{reading.glucose_value}</span>
                      <span className="text-[9px] uppercase tracking-tighter text-purple-500 mt-0.5">mg/dl</span>
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-slate-900">{reading.time_slot}</h4>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${badge.color}`}>
                          {badge.label}
                        </span>
                      </div>
                      {reading.notes ? (
                        <p className="text-xs text-slate-500 mt-0.5">&quot;{reading.notes}&quot;</p>
                      ) : (
                        <p className="text-xs text-slate-400 mt-0.5 italic">No notes provided</p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                    <button
                      onClick={() => onOpenEditModal(reading)}
                      className="px-2.5 py-1.5 text-xs font-semibold text-slate-600 hover:text-purple-700 hover:bg-purple-50 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                      <span>Edit</span>
                    </button>
                    <button
                      onClick={() => onOpenDeleteModal(reading)}
                      className="px-2.5 py-1.5 text-xs font-semibold text-slate-600 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
