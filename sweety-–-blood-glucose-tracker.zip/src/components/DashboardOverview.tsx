import React from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { GlucoseReading, TimeSlot, PERMITTED_SLOTS, DailyReport } from '../types/client.ts';
import {
  Activity,
  Plus,
  Clock,
  TrendingUp,
  ArrowDownRight,
  ArrowUpRight,
  Calendar,
  Sparkles,
  Edit2,
  Trash2,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';

interface DashboardOverviewProps {
  dailyReport: DailyReport | null;
  recentReadings: GlucoseReading[];
  onOpenAddModal: (slot?: TimeSlot, date?: string) => void;
  onOpenEditModal: (reading: GlucoseReading) => void;
  onOpenDeleteModal: (reading: GlucoseReading) => void;
  onNavigateTab: (tab: 'daily' | 'mtd' | 'monthly' | 'ai') => void;
  onSeedDemo: () => Promise<void>;
  isLoading: boolean;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  dailyReport,
  recentReadings,
  onOpenAddModal,
  onOpenEditModal,
  onOpenDeleteModal,
  onNavigateTab,
  onSeedDemo,
  isLoading,
}) => {
  const { user } = useAuth();
  const todayStr = new Date().toISOString().split('T')[0];

  const todayReadings = dailyReport?.readings || [];

  // Group today's readings by slot
  const todaySlotsMap = new Map<TimeSlot, GlucoseReading>();
  todayReadings.forEach(r => {
    todaySlotsMap.set(r.time_slot, r);
  });

  const getStatusBadge = (val: number) => {
    if (val < 70) {
      return {
        label: 'Low',
        color: 'text-amber-700 bg-amber-50 border-amber-200',
        dot: 'bg-amber-500',
      };
    }
    if (val <= 140) {
      return {
        label: 'Target',
        color: 'text-teal-700 bg-teal-50 border-teal-200',
        dot: 'bg-teal-500',
      };
    }
    if (val <= 180) {
      return {
        label: 'Elevated',
        color: 'text-purple-700 bg-purple-50 border-purple-200',
        dot: 'bg-purple-500',
      };
    }
    return {
      label: 'High',
      color: 'text-rose-700 bg-rose-50 border-rose-200',
      dot: 'bg-rose-500',
    };
  };

  return (
    <div className="space-y-6">
      {/* Hero Welcome & Today's Summary Banner */}
      <div className="bg-gradient-to-br from-white via-purple-50/30 to-teal-50/30 rounded-2xl p-6 sm:p-7 border border-slate-200/90 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-purple-700 mb-1">
              <Calendar className="w-4 h-4" />
              <span>Today, {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric', year: 'numeric' })}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Welcome back, {user?.name?.split(' ')[0] || 'Friend'}
            </h1>
            <p className="text-sm text-slate-500 mt-1 max-w-xl">
              Track your daily blood glucose curve across all four critical meal windows. Target range: 70–140 mg/dl.
            </p>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              onClick={() => onOpenAddModal()}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700 rounded-xl shadow-xs shadow-purple-200 active:scale-98 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>Log Reading</span>
            </button>
            <button
              onClick={() => onNavigateTab('ai')}
              className="inline-flex items-center gap-1.5 px-3.5 py-2.5 text-sm font-semibold text-purple-700 bg-purple-50 hover:bg-purple-100 border border-purple-200 rounded-xl transition-colors cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-purple-600" />
              <span className="hidden sm:inline">AI Analysis</span>
            </button>
          </div>
        </div>
      </div>

      {/* Today's 4-Slot Glycemic Tracker */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-2xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-base font-bold text-slate-900">Today&apos;s Meal Windows</h2>
            <p className="text-xs text-slate-500">
              {todayReadings.length} of 4 slots logged today ({4 - todayReadings.length} remaining)
            </p>
          </div>
          <button
            onClick={() => onNavigateTab('daily')}
            className="text-xs font-semibold text-purple-600 hover:text-purple-800 transition-colors cursor-pointer"
          >
            View Daily Report &rarr;
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {PERMITTED_SLOTS.map(slot => {
            const reading = todaySlotsMap.get(slot);

            if (reading) {
              const badge = getStatusBadge(reading.glucose_value);
              return (
                <div
                  key={slot}
                  className="p-4 rounded-xl border border-slate-200/80 bg-slate-50/50 hover:bg-white hover:shadow-xs transition-all relative group flex flex-col justify-between min-h-[135px]"
                >
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-xs font-semibold text-slate-600 truncate">{slot}</span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border flex items-center gap-1 ${badge.color}`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${badge.dot}`}></span>
                        {badge.label}
                      </span>
                    </div>

                    <div className="flex items-baseline gap-1 mt-1">
                      <span className="text-2xl font-extrabold text-slate-900 font-mono tabular-nums">
                        {reading.glucose_value}
                      </span>
                      <span className="text-xs text-slate-400 font-medium">mg/dL</span>
                    </div>

                    {reading.notes && (
                      <p className="text-[11px] text-slate-500 line-clamp-1 mt-1 italic">
                        &quot;{reading.notes}&quot;
                      </p>
                    )}
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-200/60 mt-2">
                    <span className="text-[10px] text-slate-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-teal-600" />
                      Recorded
                    </span>
                    <div className="flex items-center gap-1 opacity-90 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => onOpenEditModal(reading)}
                        className="p-1 text-slate-400 hover:text-purple-600 hover:bg-purple-50 rounded-md transition-colors cursor-pointer"
                        title="Edit reading"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => onOpenDeleteModal(reading)}
                        className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors cursor-pointer"
                        title="Delete reading"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            }

            return (
              <button
                key={slot}
                type="button"
                onClick={() => onOpenAddModal(slot, todayStr)}
                className="p-4 rounded-xl border-2 border-dashed border-slate-200 hover:border-purple-300 hover:bg-purple-50/30 transition-all flex flex-col items-center justify-center text-center group cursor-pointer min-h-[135px]"
              >
                <div className="w-8 h-8 rounded-full bg-slate-100 group-hover:bg-purple-100 text-slate-400 group-hover:text-purple-600 flex items-center justify-center mb-2 transition-colors">
                  <Plus className="w-4 h-4" />
                </div>
                <span className="text-xs font-semibold text-slate-700 group-hover:text-purple-700 transition-colors">
                  {slot}
                </span>
                <span className="text-[11px] text-slate-400 mt-0.5">Click to log</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Today's KPI Metric Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Average */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>Today&apos;s Average</span>
            <Activity className="w-4 h-4 text-purple-600" />
          </div>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
              {dailyReport?.average !== null && dailyReport?.average !== undefined
                ? dailyReport.average.toFixed(1)
                : '—'}
            </span>
            <span className="text-xs text-slate-400">mg/dL</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Rounded to 1 decimal place</p>
        </div>

        {/* Lowest */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>Lowest Reading</span>
            <ArrowDownRight className="w-4 h-4 text-teal-600" />
          </div>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
              {dailyReport?.lowest ?? '—'}
            </span>
            <span className="text-xs text-slate-400">mg/dL</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Daily minimum value</p>
        </div>

        {/* Highest */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>Highest Reading</span>
            <ArrowUpRight className="w-4 h-4 text-purple-600" />
          </div>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
              {dailyReport?.highest ?? '—'}
            </span>
            <span className="text-xs text-slate-400">mg/dL</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Daily maximum peak</p>
        </div>

        {/* Count */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>Readings Count</span>
            <Clock className="w-4 h-4 text-slate-600" />
          </div>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
              {dailyReport?.count ?? 0}
            </span>
            <span className="text-xs text-slate-400">/ 4 slots</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Max 4 readings / day</p>
        </div>
      </div>

      {/* Recent Glucose Readings History */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs overflow-hidden">
        <div className="p-5 sm:p-6 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-slate-900">Recent Readings Log</h2>
            <p className="text-xs text-slate-500">
              Complete audit history with slot timestamps and clinical values
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onNavigateTab('mtd')}
              className="text-xs font-medium text-slate-600 hover:text-slate-900 px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 transition-colors cursor-pointer"
            >
              Month-to-Date
            </button>
            <button
              onClick={() => onNavigateTab('monthly')}
              className="text-xs font-medium text-purple-700 hover:text-purple-900 px-3 py-1.5 rounded-lg bg-purple-50 hover:bg-purple-100 border border-purple-200 transition-colors cursor-pointer"
            >
              Monthly Report
            </button>
          </div>
        </div>

        {recentReadings.length === 0 ? (
          <div className="p-12 text-center">
            <div className="w-12 h-12 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center mx-auto mb-3">
              <Activity className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-bold text-slate-900">No glucose readings recorded yet</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 leading-relaxed">
              Log your first reading or load the clinical demo dataset to explore comprehensive reports, charts, and patterns.
            </p>
            <div className="mt-4 flex items-center justify-center gap-3">
              <button
                onClick={() => onOpenAddModal()}
                className="px-4 py-2 text-xs font-semibold text-white bg-purple-600 hover:bg-purple-700 rounded-xl transition-colors cursor-pointer"
              >
                Log First Reading
              </button>
              <button
                onClick={onSeedDemo}
                className="px-4 py-2 text-xs font-semibold text-teal-700 bg-teal-50 hover:bg-teal-100 border border-teal-200 rounded-xl transition-colors cursor-pointer"
              >
                Load Demo Dataset
              </button>
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/70 border-b border-slate-100 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                  <th className="py-3 px-4 sm:px-6">Date</th>
                  <th className="py-3 px-4">Time Slot</th>
                  <th className="py-3 px-4">Glucose Value</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 hidden md:table-cell">Notes</th>
                  <th className="py-3 px-4 sm:px-6 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {recentReadings.slice(0, 10).map(reading => {
                  const badge = getStatusBadge(reading.glucose_value);
                  return (
                    <tr key={reading.id} className="hover:bg-slate-50/60 transition-colors">
                      <td className="py-3.5 px-4 sm:px-6 font-mono text-slate-700 whitespace-nowrap">
                        {reading.reading_date}
                      </td>
                      <td className="py-3.5 px-4 font-semibold text-slate-800 whitespace-nowrap">
                        {reading.time_slot}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="font-extrabold text-slate-900 font-mono tabular-nums text-sm">
                          {reading.glucose_value}
                        </span>
                        <span className="text-[11px] text-slate-400 ml-1">mg/dl</span>
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <span className={`inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-md border ${badge.color}`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${badge.dot}`}></span>
                          {badge.label}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-500 hidden md:table-cell max-w-xs truncate">
                        {reading.notes || <span className="text-slate-300 italic">—</span>}
                      </td>
                      <td className="py-3.5 px-4 sm:px-6 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => onOpenEditModal(reading)}
                            className="p-1.5 text-slate-400 hover:text-purple-600 hover:bg-purple-50 rounded-lg transition-colors cursor-pointer"
                            title="Edit reading"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onOpenDeleteModal(reading)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                            title="Delete reading"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
