import React, { useState, useEffect } from 'react';
import { GlucoseReading, TimeSlot, PERMITTED_SLOTS } from '../types/client.ts';
import { api } from '../services/api.ts';
import { X, AlertCircle, CheckCircle2, Clock, Calendar, HeartPulse } from 'lucide-react';

interface AddEditReadingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (reading: GlucoseReading) => void;
  readingToEdit?: GlucoseReading | null;
  defaultSlot?: TimeSlot;
  defaultDate?: string;
}

export const AddEditReadingModal: React.FC<AddEditReadingModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  readingToEdit,
  defaultSlot,
  defaultDate,
}) => {
  const todayStr = new Date().toISOString().split('T')[0];

  const [date, setDate] = useState<string>(defaultDate || todayStr);
  const [slot, setSlot] = useState<TimeSlot>(defaultSlot || 'Morning (fasting)');
  const [value, setValue] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (readingToEdit) {
      setDate(readingToEdit.reading_date);
      setSlot(readingToEdit.time_slot);
      setValue(String(readingToEdit.glucose_value));
      setNotes(readingToEdit.notes || '');
    } else {
      setDate(defaultDate || todayStr);
      setSlot(defaultSlot || 'Morning (fasting)');
      setValue('');
      setNotes('');
    }
    setErrorMessage(null);
  }, [readingToEdit, isOpen, defaultDate, defaultSlot]);

  if (!isOpen) return null;

  const numVal = parseInt(value, 10);
  const isValidInteger = !isNaN(numVal) && Number.isInteger(Number(value));

  // Determine clinical range category
  const getRangeBadge = () => {
    if (!value || isNaN(numVal)) return null;
    if (numVal < 40 || numVal > 600) {
      return (
        <span className="text-xs font-semibold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-md">
          Out of permitted range (40 - 600)
        </span>
      );
    }
    if (numVal < 70) {
      return (
        <span className="text-xs font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
          Hypoglycemia (Low)
        </span>
      );
    }
    if (numVal <= 140) {
      return (
        <span className="text-xs font-semibold text-teal-700 bg-teal-50 px-2 py-0.5 rounded-md flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-teal-500"></span>
          In Target (Optimal)
        </span>
      );
    }
    if (numVal <= 180) {
      return (
        <span className="text-xs font-semibold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-md flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-purple-500"></span>
          Elevated
        </span>
      );
    }
    return (
      <span className="text-xs font-semibold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md flex items-center gap-1">
        <span className="w-1.5 h-1.5 rounded-full bg-rose-500"></span>
        Hyperglycemia (High)
      </span>
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    // 1. Client-Side Validation according to assessment specifications
    if (!value || value.trim() === '') {
      setErrorMessage('Glucose value is required.');
      return;
    }

    if (!isValidInteger) {
      setErrorMessage('Glucose value must be a whole number (integer). Decimals are not permitted.');
      return;
    }

    if (numVal < 40 || numVal > 600) {
      setErrorMessage('Glucose value must be between 40 and 600 mg/dl.');
      return;
    }

    if (!PERMITTED_SLOTS.includes(slot)) {
      setErrorMessage(`Please select one of the 4 permitted slots: ${PERMITTED_SLOTS.join(', ')}`);
      return;
    }

    if (!date) {
      setErrorMessage('Date is required.');
      return;
    }

    if (date > todayStr) {
      setErrorMessage('Future dates are not allowed. Please select today or an earlier date.');
      return;
    }

    setIsSubmitting(true);

    try {
      if (readingToEdit) {
        const res = await api.updateReading(readingToEdit.id, {
          reading_date: date,
          time_slot: slot,
          glucose_value: numVal,
          notes: notes.trim() || undefined,
        });
        onSuccess(res.reading);
      } else {
        const res = await api.createReading({
          reading_date: date,
          time_slot: slot,
          glucose_value: numVal,
          notes: notes.trim() || undefined,
        });
        onSuccess(res.reading);
      }
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to save glucose reading.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs transition-opacity animate-fade-in">
      <div
        className="bg-white rounded-2xl shadow-xl border border-slate-200/90 w-full max-w-lg overflow-hidden flex flex-col max-h-[92vh]"
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-headline"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4.5 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center">
              <HeartPulse className="w-5 h-5" />
            </div>
            <div>
              <h3 id="modal-headline" className="text-lg font-bold text-slate-900">
                {readingToEdit ? 'Edit Glucose Reading' : 'Log Blood Glucose Reading'}
              </h3>
              <p className="text-xs text-slate-500">
                {readingToEdit ? 'Update existing clinical record' : 'Record a new entry for your daily log'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 overflow-y-auto">
          {errorMessage && (
            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-3 text-rose-800 text-sm">
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold">Validation Error</p>
                <p className="text-rose-700 text-xs mt-0.5">{errorMessage}</p>
              </div>
            </div>
          )}

          {/* Date Picker */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-purple-600" />
              Reading Date
            </label>
            <input
              type="date"
              max={todayStr}
              value={date}
              onChange={e => setDate(e.target.value)}
              required
              className="w-full px-3.5 py-2.5 bg-white border border-slate-200 rounded-xl text-slate-900 text-sm focus:outline-hidden focus:border-purple-600 focus:ring-2 focus:ring-purple-100 transition-all font-mono"
            />
            <p className="text-[11px] text-slate-400 mt-1">Future dates are strictly restricted.</p>
          </div>

          {/* Time Slot Selection (Permitted 4 slots) */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-teal-600" />
              Time Slot (Select One)
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {PERMITTED_SLOTS.map(s => {
                const isSelected = slot === s;
                return (
                  <button
                    type="button"
                    key={s}
                    onClick={() => setSlot(s)}
                    className={`flex items-center justify-between p-3 rounded-xl border text-xs font-medium transition-all text-left cursor-pointer ${
                      isSelected
                        ? 'border-purple-600 bg-purple-50/80 text-purple-900 font-semibold shadow-2xs ring-1 ring-purple-600'
                        : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <span>{s}</span>
                    {isSelected && <CheckCircle2 className="w-4 h-4 text-purple-600 shrink-0" />}
                  </button>
                );
              })}
            </div>
            <p className="text-[11px] text-slate-400 mt-1.5">
              Only one reading per slot per day is allowed (maximum 4 daily).
            </p>
          </div>

          {/* Glucose Value Input */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider">
                Glucose Value (mg/dl) <span className="text-rose-500">*</span>
              </label>
              {getRangeBadge()}
            </div>
            <div className="relative">
              <input
                type="number"
                min="40"
                max="600"
                step="1"
                placeholder="e.g. 110"
                value={value}
                onChange={e => setValue(e.target.value)}
                required
                className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-slate-900 text-lg font-bold tabular-nums focus:outline-hidden focus:border-purple-600 focus:ring-2 focus:ring-purple-100 transition-all placeholder:text-slate-300"
              />
              <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-semibold text-slate-400 pointer-events-none">
                mg/dL
              </span>
            </div>
            <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1">
              <span>Must be a whole number between 40 and 600</span>
              <span className="font-mono">Normal: 70–140 mg/dL</span>
            </div>
          </div>

          {/* Notes (Optional) */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Clinical / Meal Notes (Optional)
            </label>
            <textarea
              rows={2}
              placeholder="e.g. Oatmeal with blueberries, 20-min post-meal walk"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-white border border-slate-200 rounded-xl text-slate-900 text-xs focus:outline-hidden focus:border-purple-600 focus:ring-2 focus:ring-purple-100 transition-all resize-none placeholder:text-slate-300"
            />
          </div>

          {/* Action Buttons */}
          <div className="pt-2 flex items-center justify-end gap-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2.5 text-xs font-semibold text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2.5 text-xs font-semibold text-white bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700 rounded-xl shadow-sm shadow-purple-200 disabled:opacity-60 transition-all cursor-pointer flex items-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white/40 border-t-white rounded-full animate-spin"></div>
                  <span>Saving...</span>
                </>
              ) : (
                <span>{readingToEdit ? 'Save Changes' : 'Record Reading'}</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
