import React, { useState, useEffect } from 'react';
import { AiInsights } from '../types/client.ts';
import { api } from '../services/api.ts';
import {
  Sparkles,
  RefreshCw,
  AlertCircle,
  Lightbulb,
  CheckCircle2,
  ShieldAlert,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';

export const AiInsightsView: React.FC = () => {
  const [insights, setInsights] = useState<AiInsights | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchInsights = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await api.getAiInsights();
      setInsights(data);
    } catch (err: any) {
      setError(err.message || 'Failed to generate AI insights');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchInsights();
  }, []);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-semibold text-purple-700 uppercase tracking-wider flex items-center gap-1.5 mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            AI & Clinical Pattern Engine
          </span>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
            Glycemic Analysis & Insights
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Powered by Gemini AI and evidence-based clinical diabetes guidelines
          </p>
        </div>

        <button
          onClick={fetchInsights}
          disabled={isLoading}
          className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-purple-700 bg-purple-50 hover:bg-purple-100 border border-purple-200 rounded-xl transition-colors disabled:opacity-50 cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          <span>Refresh Analysis</span>
        </button>
      </div>

      {error && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {isLoading ? (
        <div className="bg-white rounded-2xl p-16 text-center border border-slate-200/90 shadow-2xs">
          <div className="w-10 h-10 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center mx-auto mb-3 animate-pulse">
            <Sparkles className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-bold text-slate-900">Analyzing Recent Glucose Dynamics...</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            Evaluating fasting trends, postprandial spikes, and glycemic excursions across meal windows.
          </p>
        </div>
      ) : insights ? (
        <div className="space-y-6">
          {/* Executive Summary Card */}
          <div className="bg-gradient-to-r from-purple-900 to-indigo-900 text-white rounded-2xl p-6 sm:p-7 shadow-md">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-purple-200 uppercase tracking-wider flex items-center gap-1.5">
                <TrendingUp className="w-4 h-4 text-teal-400" />
                Glycemic Stability Rating
              </span>
              <span className="px-3 py-1 rounded-full text-xs font-extrabold bg-white/20 backdrop-blur-md text-white border border-white/20">
                {insights.glycemicStability}
              </span>
            </div>
            <p className="text-base sm:text-lg font-medium text-purple-50 leading-relaxed mt-3">
              {insights.summary}
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Pattern Highlights */}
            <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-2xs">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Observed Patterns</h3>
                  <p className="text-[11px] text-slate-400">Key trends detected across daily slots</p>
                </div>
              </div>

              <ul className="space-y-3">
                {insights.highlights.map((highlight, idx) => (
                  <li
                    key={idx}
                    className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 text-xs text-slate-700 leading-relaxed flex items-start gap-2.5"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-purple-600 shrink-0 mt-1.5"></span>
                    <span>{highlight}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Recommendations */}
            <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-2xs">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-teal-50 text-teal-600 flex items-center justify-center">
                  <Lightbulb className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Actionable Recommendations</h3>
                  <p className="text-[11px] text-slate-400">Clinically informed lifestyle suggestions</p>
                </div>
              </div>

              <ul className="space-y-3">
                {insights.recommendations.map((rec, idx) => (
                  <li
                    key={idx}
                    className="p-3.5 rounded-xl bg-teal-50/40 border border-teal-100 text-xs text-slate-800 leading-relaxed flex items-start gap-2.5"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-teal-600 shrink-0 mt-1.5"></span>
                    <span>{rec}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Medical Disclaimer */}
          <div className="p-4 bg-amber-50/80 border border-amber-200/80 rounded-2xl flex items-start gap-3 text-xs text-amber-900">
            <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Clinical Disclaimer</p>
              <p className="text-amber-800 text-[11px] mt-0.5 leading-relaxed">
                Sweety provides lifestyle tracking and pattern analytics for informational purposes only. It is not intended as medical diagnosis, prescription, or emergency advisory. Always consult your personal endocrinologist or primary care physician for diabetes medication adjustments.
              </p>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};
