import React from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { Activity, Plus, LogOut, User as UserIcon } from 'lucide-react';

export type ActiveTab = 'dashboard' | 'daily' | 'mtd' | 'monthly' | 'ai';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenAddModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab, onOpenAddModal }) => {
  const { user, logout } = useAuth();

  const navLinks: { id: ActiveTab; label: string }[] = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'daily', label: 'Daily Report' },
    { id: 'mtd', label: 'Month-to-Date' },
    { id: 'monthly', label: 'Monthly Report' },
    { id: 'ai', label: 'AI Insights' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-4 md:gap-8 h-16">
          {/* Zone 1: Single Brand Wordmark */}
          <div className="flex items-center gap-2.5 shrink-0">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 to-teal-500 flex items-center justify-center text-white shadow-sm shadow-purple-200">
              <Activity className="w-5 h-5" />
            </div>
            <button
              onClick={() => setActiveTab('dashboard')}
              className="text-left group cursor-pointer focus:outline-hidden"
            >
              <span className="text-xl font-bold tracking-tight text-slate-900 group-hover:text-purple-700 transition-colors">
                Sweety
              </span>
              <span className="hidden sm:inline-block ml-2 text-xs font-medium text-teal-600 bg-teal-50 px-2 py-0.5 rounded-md border border-teal-100">
                Glucose Tracker
              </span>
            </button>
          </div>

          {/* Zone 2: 4-5 Clean Single-Line Text Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1">
            {navLinks.map(link => {
              const isActive = activeTab === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => setActiveTab(link.id)}
                  className={`px-3.5 py-2 text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    isActive
                      ? 'text-purple-800 bg-purple-50 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
                  }`}
                >
                  {link.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Primary Action & User Session */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <button
              onClick={onOpenAddModal}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-sm font-semibold text-white bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700 rounded-lg shadow-sm shadow-purple-200 active:scale-98 transition-all cursor-pointer whitespace-nowrap shrink-0"
              title="Record new glucose reading"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span className="hidden sm:inline">Log Reading</span>
            </button>

            {/* User Profile & Logout */}
            <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
              <div className="hidden sm:flex flex-col text-right">
                <span className="text-xs font-bold text-slate-800 truncate max-w-[120px]">
                  {user?.name}
                </span>
                <span className="text-[11px] text-slate-500 truncate max-w-[120px]">
                  {user?.email}
                </span>
              </div>
              <button
                onClick={logout}
                className="p-2 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                title="Log out of Sweety"
                aria-label="Log out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation Row */}
        <div className="flex lg:hidden overflow-x-auto pb-2 gap-1 scrollbar-none border-t border-slate-100 pt-1">
          {navLinks.map(link => {
            const isActive = activeTab === link.id;
            return (
              <button
                key={link.id}
                onClick={() => setActiveTab(link.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                  isActive
                    ? 'text-purple-800 bg-purple-50 font-semibold'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {link.label}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
